import json
from pathlib import Path

from rich.console import Console
from alignerr.commands.results import DefaultResultHandler
from alignerr.schemas import EvaluationStatus
from alignerr.api.client import APIClient

console = Console()


class BenchmarkResultHandler(DefaultResultHandler):
    def process_artifacts(
        self, 
        client: APIClient, 
        task_id: str, 
        output_dir: Path, 
        downloaded_artifacts: set = None
    ) -> tuple[dict, dict, set]:
        """Download and process artifacts, including validation results."""
        results, html_reports, downloaded_artifacts = super().process_artifacts(
            client, task_id, output_dir, downloaded_artifacts
        )
        
        # Load validation result
        for validation_json in output_dir.rglob("validation_result.json"):
            validation_data = json.loads(validation_json.read_text())
            results["validation-results"] = validation_data
            break
        
        # Load evaluation results (agent result.json files)
        eval_results = []
        for result_json in output_dir.rglob("result.json"):
            eval_results.append(json.loads(result_json.read_text()))
        
        if eval_results:
            results["evaluation-results"] = eval_results
        
        return results, html_reports, downloaded_artifacts
    
    def determine_status(self, results: dict) -> EvaluationStatus:
        """Determine evaluation status - controls polling behavior."""
        validation_results = results.get("validation-results", {})
        eval_results = results.get("evaluation-results")
        
        if validation_results:
            status = validation_results.get("status")
            if status in ["invalid", "error"]:
                return EvaluationStatus.FAILED
            if status == "valid" and eval_results:
                return EvaluationStatus.PASSED
        
        return super().determine_status(results)
    
    def display_results(self, results: dict, html_reports: dict) -> None:
        """Display results with validation-aware formatting."""
        validation_results = results.get("validation-results", {})
        
        if validation_results:
            status = validation_results.get("status", "unknown")
            if status in ["invalid", "error"]:
                console.print(f"\n[bold red]Validation {status.upper()}[/bold red]")
                self._print_validation_issues(validation_results)
                console.print("\n[yellow]Evaluation was skipped due to validation failure[/yellow]")
                return
        
        super().display_results(results, html_reports)
    
    def display_status(self, status: EvaluationStatus) -> None:
        """Display the final status message."""
        if status == EvaluationStatus.FAILED:
            console.print("\n[bold red]❌ Validation failed - fix issues and resubmit[/bold red]")
        else:
            super().display_status(status)
    
    def _print_validation_issues(self, validation_results: dict) -> None:
        """Print validation issues for quick feedback."""
        stages = validation_results.get("stages", {})
        for stage_name, stage_data in stages.items():
            if not stage_data.get("passed", True):
                console.print(f"\n[red]Stage failed: {stage_name}[/red]")
                for issue in stage_data.get("issues", []):
                    console.print(f"  - {issue}")
