def format_action(action_data: dict) -> str:
    if not action_data:
        return "No action"
    
    function = action_data.get("function", "unknown")
    arguments = action_data.get("arguments", {})
    
    if not arguments:
        return function
    
    arg_strs = []
    for key, value in arguments.items():
        arg_strs.append(f"{key}={repr(value)}")
    
    return f"{function}({', '.join(arg_strs)})"

def format_ground_truth_step(step_data: dict) -> str:
    step = step_data.get("step", 0)
    comment = step_data.get("comment", "")
    url = step_data.get("url", "")
    screenshot = step_data.get("screenshot", "")
    
    step_html = f"""
            <div class="step">
                <div class="step-header">
                    <div class="step-number">Step {step}</div>
                    <div class="step-url">{url}</div>
                </div>
                <div class="step-content">"""
    
    if screenshot:
        step_html += f"""
                    <div class="step-field">
                        <div class="step-field-label">Screenshot</div>
                        <div class="screenshot-container">
                            <img src="{screenshot}" alt="Ground truth step {step} screenshot" class="screenshot">
                        </div>
                    </div>"""
    
    if comment:
        step_html += f"""
                    <div class="step-field">
                        <div class="step-field-label">Action</div>
                        <div class="step-field-value">{comment}</div>
                    </div>"""
    
    step_html += """
                </div>
            </div>"""
    
    return step_html

def format_trajectory_step(step_data: dict) -> str:
    step = step_data.get("step", 0)
    url = step_data.get("url", "")
    observation = step_data.get("observation", "")
    action = step_data.get("action", {})
    result = step_data.get("result", "")
    screenshot = step_data.get("screenshot", "")
    
    action_str = format_action(action)
    
    has_long_observation = len(observation) > 1000
    
    step_html = f"""
            <div class="step">
                <div class="step-header">
                    <div class="step-number">Step {step}</div>
                    <div class="step-url">{url}</div>
                </div>
                <div class="step-content">"""
    
    if screenshot:
        step_html += f"""
                    <div class="step-field">
                        <div class="step-field-label">Screenshot</div>
                        <div class="screenshot-container">
                            <img src="{screenshot}" alt="Step {step} screenshot" class="screenshot">
                        </div>
                    </div>"""
    
    if observation:
        if has_long_observation:
            step_html += f"""
                    <div class="step-field">
                        <div class="step-field-label">Observation (Click to expand/collapse)</div>
                        <div class="step-field-value">
                            <div class="collapsible" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? 'block' : 'none'">
                                ▶ Click to view full observation ({len(observation)} characters)
                            </div>
                            <div class="collapsible-content" style="display: none;">{observation}</div>
                        </div>
                    </div>"""
        else:
            step_html += f"""
                    <div class="step-field">
                        <div class="step-field-label">Observation</div>
                        <div class="step-field-value">
                            <pre>{observation}</pre>
                        </div>
                    </div>"""
    
    if action:
        step_html += f"""
                    <div class="step-field">
                        <div class="step-field-label">Action</div>
                        <div class="step-field-value">{action_str}</div>
                    </div>"""
    
    if result:
        step_html += f"""
                    <div class="step-field">
                        <div class="step-field-label">Result</div>
                        <div class="step-field-value">{result}</div>
                    </div>"""
    
    step_html += """
                </div>
            </div>"""
    
    return step_html
