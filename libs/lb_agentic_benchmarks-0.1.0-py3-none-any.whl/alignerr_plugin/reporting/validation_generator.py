import json
from pathlib import Path
from alignerr_plugin.reporting.validation_template import render_validation_report

def generate_validation_report(validation_dir: Path, output_path: Path) -> None:
    validation_json = validation_dir / "validation_result.json"
    data = json.loads(validation_json.read_text())
    html_content = render_validation_report(data)
    output_path.write_text(html_content)

