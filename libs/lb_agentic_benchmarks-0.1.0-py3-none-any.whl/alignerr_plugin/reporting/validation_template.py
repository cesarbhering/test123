def render_validation_report(data: dict) -> str:
    problem_id = data.get("problem_id", "unknown")
    benchmark = data.get("benchmark", "unknown")
    status = data.get("status", "unknown")
    timestamp = data.get("timestamp", "")
    stages = data.get("stages", {})
    metadata = data.get("metadata", {})
    
    status_color = {
        "valid": "#22c55e",
        "invalid": "#ef4444",
        "error": "#f59e0b",
    }.get(status.lower(), "#6b7280")
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation Report: {problem_id}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #1f2937;
            background: #f9fafb;
            padding: 2rem;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }}
        
        .header {{
            padding: 2rem;
            border-bottom: 2px solid #e5e7eb;
        }}
        
        .header h1 {{
            font-size: 1.875rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: #111827;
        }}
        
        .status-badge {{
            display: inline-block;
            padding: 0.375rem 0.875rem;
            border-radius: 4px;
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            background: {status_color};
            color: white;
        }}
        
        .metadata {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
        }}
        
        .metadata-item {{
            padding: 1rem;
            background: #f9fafb;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
        }}
        
        .metadata-label {{
            font-size: 0.875rem;
            color: #6b7280;
            margin-bottom: 0.25rem;
        }}
        
        .metadata-value {{
            font-size: 1.125rem;
            font-weight: 600;
            color: #111827;
        }}
        
        .section {{
            padding: 2rem;
            border-bottom: 1px solid #e5e7eb;
        }}
        
        .section:last-child {{
            border-bottom: none;
        }}
        
        .section-title {{
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #111827;
        }}
        
        .stage {{
            margin-bottom: 1.5rem;
            padding: 1.5rem;
            background: #f9fafb;
            border-radius: 6px;
            border-left: 4px solid #d1d5db;
        }}
        
        .stage.passed {{
            border-left-color: #22c55e;
            background: #f0fdf4;
        }}
        
        .stage.failed {{
            border-left-color: #ef4444;
            background: #fef2f2;
        }}
        
        .stage-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }}
        
        .stage-name {{
            font-weight: 700;
            font-size: 1.125rem;
            color: #111827;
        }}
        
        .stage-status {{
            padding: 0.25rem 0.75rem;
            border-radius: 4px;
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
        }}
        
        .stage-status.passed {{
            background: #22c55e;
            color: white;
        }}
        
        .stage-status.failed {{
            background: #ef4444;
            color: white;
        }}
        
        .stage-details {{
            display: grid;
            gap: 0.5rem;
        }}
        
        .stage-detail {{
            display: grid;
            grid-template-columns: 150px 1fr;
            gap: 1rem;
        }}
        
        .detail-label {{
            font-weight: 600;
            color: #4b5563;
        }}
        
        .detail-value {{
            color: #1f2937;
            font-family: monospace;
            font-size: 0.875rem;
        }}
        
        .issues-list {{
            margin-top: 0.75rem;
            padding: 1rem;
            background: white;
            border-radius: 4px;
            border: 1px solid #e5e7eb;
        }}
        
        .issue-item {{
            padding: 0.5rem;
            background: #fef2f2;
            border-left: 3px solid #ef4444;
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
        }}
        
        .issue-item:last-child {{
            margin-bottom: 0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Validation Report: {problem_id}</h1>
            <div>
                <span class="status-badge">{status}</span>
            </div>
            <div class="metadata">
                <div class="metadata-item">
                    <div class="metadata-label">Benchmark</div>
                    <div class="metadata-value">{benchmark}</div>
                </div>
                <div class="metadata-item">
                    <div class="metadata-label">Timestamp</div>
                    <div class="metadata-value">{timestamp}</div>
                </div>"""
    
    num_tasks = metadata.get("num_tasks")
    if num_tasks is not None:
        html += f"""
                <div class="metadata-item">
                    <div class="metadata-label">Number of Tasks</div>
                    <div class="metadata-value">{num_tasks}</div>
                </div>"""
    
    description = metadata.get("description")
    if description:
        html += f"""
                <div class="metadata-item">
                    <div class="metadata-label">Description</div>
                    <div class="metadata-value">{description}</div>
                </div>"""
    
    html += """
            </div>
        </div>"""
    
    if stages:
        html += """
        <div class="section">
            <h2 class="section-title">Validation Stages</h2>"""
        
        for stage_name, stage_data in stages.items():
            passed = stage_data.get("passed", False)
            stage_class = "passed" if passed else "failed"
            status_text = "PASSED" if passed else "FAILED"
            
            html += f"""
            <div class="stage {stage_class}">
                <div class="stage-header">
                    <div class="stage-name">{stage_name.replace('_', ' ').title()}</div>
                    <div class="stage-status {stage_class}">{status_text}</div>
                </div>
                <div class="stage-details">"""
            
            stage_timestamp = stage_data.get("timestamp")
            if stage_timestamp:
                html += f"""
                    <div class="stage-detail">
                        <div class="detail-label">Timestamp</div>
                        <div class="detail-value">{stage_timestamp}</div>
                    </div>"""
            
            duration_ms = stage_data.get("duration_ms")
            if duration_ms is not None:
                duration_sec = duration_ms / 1000
                html += f"""
                    <div class="stage-detail">
                        <div class="detail-label">Duration</div>
                        <div class="detail-value">{duration_sec:.2f}s</div>
                    </div>"""
            
            issues = stage_data.get("issues", [])
            if issues:
                html += """
                    <div class="issues-list">
                        <div style="font-weight: 600; margin-bottom: 0.5rem;">Issues:</div>"""
                for issue in issues:
                    html += f"""
                        <div class="issue-item">{issue}</div>"""
                html += """
                    </div>"""
            
            html += """
                </div>
            </div>"""
        
        html += """
        </div>"""
    
    html += """
    </div>
</body>
</html>"""
    
    return html

