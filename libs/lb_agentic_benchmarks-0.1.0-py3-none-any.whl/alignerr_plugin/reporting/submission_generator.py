import json
from pathlib import Path
from alignerr_plugin.reporting.submission_template import render_submission_report
from alignerr_plugin.reporting.charts import generate_radar_chart
from alignerr_plugin.reporting.metrics_dashboard import generate_metrics_summary_html, generate_task_metrics_table

METRIC_MAX_VALUES = {
    "agent_turns": 250,
    "runtime_seconds": 3600,
}

def generate_submission_report(
    result_dir: Path,
    project_root: Path,
    output_path: Path,
    validation_data: dict | None = None,
    problem_id: str | None = None,
    agents_data: dict[str, Path] | None = None,
    validation_report_path: str | None = None,
) -> None:
    agents_tasks = {}
    
    for agent_name, problem_dir in agents_data.items():
        tasks_data = []
        for item in problem_dir.iterdir():
            if item.is_dir() and (item / "result.json").exists():
                result_json = item / "result.json"
                task_result = json.loads(result_json.read_text())
                task_result["agent_name"] = agent_name
                tasks_data.append(task_result)
        tasks_data.sort(key=lambda x: x.get("task_id", ""))
        agents_tasks[agent_name] = tasks_data
    
    radar_chart_html = generate_radar_chart_multi_agent(agents_tasks)
    
    all_results = []
    for agent_name, tasks in agents_tasks.items():
        all_results.extend(tasks)
    
    metrics_summary_html = generate_metrics_summary_html(all_results)
    metrics_table_html = generate_task_metrics_table(all_results)
    
    failed_tasks_details = collect_failed_task_details(agents_tasks)
    
    html_content = render_submission_report(
        problem_id,
        validation_data,
        agents_tasks,
        radar_chart_html,
        validation_report_path,
        metrics_summary_html=metrics_summary_html,
        metrics_table_html=metrics_table_html,
        failed_tasks_details=failed_tasks_details,
    )
    
    output_path.write_text(html_content)


def collect_failed_task_details(agents_tasks: dict[str, list[dict]]) -> list[dict]:
    """Collect details of failed tasks for display in the report."""
    failed_details = []
    for agent_name, tasks in agents_tasks.items():
        for task in tasks:
            status = task.get("status", "unknown")
            if status in ["passed", "success"]:
                continue
            
            task_id = task.get("task_id", "unknown")
            task_name = task_id.split("-")[-1] if "-" in task_id else task_id
            details = task.get("details", {})
            quality_metrics = task.get("quality_metrics", {})
            
            failed_details.append({
                "agent_name": agent_name,
                "task_name": task_name,
                "task_id": task_id,
                "intent": details.get("intent", "N/A"),
                "evaluation": details.get("evaluation", "N/A"),
                "failure_mode": quality_metrics.get("failure_mode", "unknown"),
                "final_url": details.get("final_url", ""),
            })
    
    return failed_details


def generate_radar_chart_multi_agent(agents_tasks: dict[str, list[dict]]) -> str:
    task_map = {}
    for agent_name, tasks in agents_tasks.items():
        for task in tasks:
            task_id = task.get("task_id", "")
            task_name = task_id.split("-")[-1] if "-" in task_id else task_id
            if task_name not in task_map:
                task_map[task_name] = {}
            task_map[task_name][agent_name] = task
    
    if not task_map:
        return "<div>No tasks available for chart</div>"
    
    charts_html = ""
    for task_name, agents_data in sorted(task_map.items()):
        all_metrics = set()
        for task in agents_data.values():
            all_metrics.update(task.get("metrics", {}).keys())
        
        all_metrics = sorted(list(all_metrics))
        
        if not all_metrics:
            continue
        
        agents_radar_data = []
        for agent_name, task in agents_data.items():
            metrics = task.get("metrics", {})
            normalized_values = []
            actual_values = []
            for metric in all_metrics:
                val = metrics.get(metric)
                actual_values.append(f"{metric}: {val}" if val is not None else f"{metric}: N/A")
                
                if val is None:
                    normalized_values.append(0)
                    continue
                
                max_val = METRIC_MAX_VALUES.get(metric, 100)
                
                if metric in ["runtime_seconds", "agent_turns"]:
                    normalized = max(0, 1.0 - val / max_val)
                else:
                    normalized = min(1.0, val / max_val)
                
                normalized_values.append(normalized)
            
            agents_radar_data.append({
                "agent_name": agent_name,
                "scores": normalized_values,
                "hover_text": actual_values,
            })
        
        chart_html = generate_radar_chart(agents_radar_data, all_metrics, f"Task: {task_name}")
        charts_html += f"""
            <div class="chart-container" style="margin-bottom: 2rem;">
                <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 1rem; color: #374151;">{task_name}</h3>
                {chart_html}
            </div>"""
    
    return charts_html

