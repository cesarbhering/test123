from alignerr_plugin.reporting.data_loader import ReportData
from alignerr_plugin.reporting.formatters import format_trajectory_step, format_ground_truth_step

def render_html_report(data: ReportData) -> str:
    status_lower = data.status.lower()
    status_color = {
        "passed": "#22c55e",
        "success": "#22c55e",
        "failed": "#ef4444",
        "error": "#f59e0b",
    }.get(status_lower, "#6b7280")
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluation Report: {data.task_id}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #1f2937;
            background: #f9fafb;
            padding: 2rem;
        }}
        
        .container {{
            max-width: 1800px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }}
        
        .header {{
            padding: 2rem;
            border-bottom: 2px solid #e5e7eb;
        }}
        
        .header h1 {{
            font-size: 1.875rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: #111827;
        }}
        
        .status-badge {{
            display: inline-block;
            padding: 0.375rem 0.875rem;
            border-radius: 4px;
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            background: {status_color};
            color: white;
        }}
        
        .metrics {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
        }}
        
        .metric {{
            padding: 1rem;
            background: #f9fafb;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
        }}
        
        .metric-label {{
            font-size: 0.875rem;
            color: #6b7280;
            margin-bottom: 0.25rem;
        }}
        
        .metric-value {{
            font-size: 1.5rem;
            font-weight: 700;
            color: #111827;
        }}
        
        .section {{
            padding: 2rem;
            border-bottom: 1px solid #e5e7eb;
        }}
        
        .section:last-child {{
            border-bottom: none;
        }}
        
        .section-title {{
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: #111827;
        }}
        
        .section-subtitle {{
            font-size: 1.125rem;
            font-weight: 600;
            margin-top: 1.5rem;
            margin-bottom: 0.75rem;
            color: #374151;
        }}
        
        .info-grid {{
            display: grid;
            gap: 0.75rem;
            margin-top: 1rem;
        }}
        
        .info-item {{
            display: grid;
            grid-template-columns: 200px 1fr;
            gap: 1rem;
        }}
        
        .info-label {{
            font-weight: 600;
            color: #4b5563;
        }}
        
        .info-value {{
            color: #1f2937;
        }}
        
        .code-block {{
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            padding: 1rem;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.875rem;
            overflow-x: auto;
            margin-top: 0.5rem;
        }}
        
        .step {{
            margin-bottom: 2rem;
            padding: 1.5rem;
            background: #f9fafb;
            border-radius: 6px;
            border-left: 4px solid #3b82f6;
        }}
        
        .step-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }}
        
        .step-number {{
            font-weight: 700;
            font-size: 1.125rem;
            color: #3b82f6;
        }}
        
        .step-url {{
            font-size: 0.875rem;
            color: #6b7280;
            font-family: monospace;
        }}
        
        .step-content {{
            display: grid;
            gap: 1rem;
        }}
        
        .step-field {{
            background: white;
            padding: 1rem;
            border-radius: 4px;
            border: 1px solid #e5e7eb;
        }}
        
        .step-field-label {{
            font-weight: 600;
            color: #4b5563;
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
        }}
        
        .step-field-value {{
            color: #1f2937;
            font-size: 0.875rem;
        }}
        
        .step-field-value pre {{
            white-space: pre-wrap;
            word-wrap: break-word;
            margin: 0;
            font-family: 'Courier New', Courier, monospace;
        }}
        
        .screenshot {{
            max-width: 100%;
            border: 1px solid #e5e7eb;
            border-radius: 4px;
            margin-top: 0.5rem;
        }}
        
        .screenshot-container {{
            background: white;
            padding: 1rem;
            border-radius: 4px;
            border: 1px solid #e5e7eb;
        }}
        
        .comparison-header {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-top: 1.5rem;
            margin-bottom: 1rem;
        }}
        
        .comparison-row {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
            align-items: start;
        }}
        
        .trajectory-column {{
            min-width: 0;
        }}
        
        .column-header {{
            padding: 1rem;
            background: #f3f4f6;
            border-radius: 6px;
            font-weight: 700;
            font-size: 1.125rem;
            text-align: center;
        }}
        
        .ground-truth-header {{
            background: #dbeafe;
            color: #1e40af;
        }}
        
        .model-header {{
            background: #f3e8ff;
            color: #6b21a8;
        }}
        
        .empty-step {{
            padding: 1.5rem;
            background: #f9fafb;
            border-radius: 6px;
            border-left: 4px solid #d1d5db;
            color: #9ca3af;
            text-align: center;
            font-style: italic;
        }}
        
        .action-list {{
            list-style: none;
            padding: 0;
        }}
        
        .action-list li {{
            padding: 0.75rem 1rem;
            background: #f9fafb;
            margin-bottom: 0.5rem;
            border-radius: 4px;
            border-left: 3px solid #6b7280;
            font-family: monospace;
            font-size: 0.875rem;
        }}
        
        .task-intent {{
            padding: 1.5rem;
            background: #eff6ff;
            border-left: 4px solid #3b82f6;
            border-radius: 4px;
            margin-top: 1rem;
        }}
        
        .evaluation-result {{
            padding: 1.5rem;
            background: #fef2f2;
            border-left: 4px solid #ef4444;
            border-radius: 4px;
            margin-top: 1rem;
        }}
        
        .evaluation-result.success {{
            background: #f0fdf4;
            border-left-color: #22c55e;
        }}
        
        .params-grid {{
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 0.5rem 1rem;
            margin-top: 0.75rem;
        }}
        
        .param-key {{
            font-weight: 600;
            color: #4b5563;
        }}
        
        .param-value {{
            color: #1f2937;
            font-family: monospace;
            font-size: 0.875rem;
        }}
        
        .collapsible {{
            cursor: pointer;
            padding: 0.75rem 1rem;
            background: #f3f4f6;
            border: 1px solid #d1d5db;
            border-radius: 4px;
            margin-top: 0.5rem;
            font-weight: 600;
            font-size: 0.875rem;
            color: #374151;
        }}
        
        .collapsible:hover {{
            background: #e5e7eb;
        }}
        
        .collapsible-content {{
            max-height: 300px;
            overflow-y: auto;
            margin-top: 0.5rem;
            padding: 1rem;
            background: #fafafa;
            border: 1px solid #e5e7eb;
            border-radius: 4px;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.8rem;
            white-space: pre-wrap;
            word-wrap: break-word;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{data.task_id}</h1>
            <div>
                <span class="status-badge">{data.status}</span>
            </div>
            <div class="metrics">"""
    
    for key, value in data.metrics.items():
        html += f"""
                <div class="metric">
                    <div class="metric-label">{key.replace('_', ' ').title()}</div>
                    <div class="metric-value">{value}</div>
                </div>"""
    
    if data.timing_ms:
        total_ms = data.timing_ms.get("total", 0)
        total_sec = total_ms / 1000
        html += f"""
                <div class="metric">
                    <div class="metric-label">Total Time</div>
                    <div class="metric-value">{total_sec:.2f}s</div>
                </div>"""
    
    html += """
            </div>
        </div>"""
    
    if data.artifacts and any("video" in artifact for artifact in data.artifacts):
        video_artifact = next((a for a in data.artifacts if "video" in a), None)
        if video_artifact:
            html += f"""
        <div class="section">
            <h2 class="section-title">Video Recording</h2>
            <video controls style="max-width: 100%; border-radius: 6px; border: 1px solid #e5e7eb;">
                <source src="{video_artifact}" type="video/webm">
                Your browser does not support the video tag.
            </video>
        </div>"""
    
    if data.details:
        html += """
        <div class="section">
            <h2 class="section-title">Evaluation Result</h2>"""
        
        eval_result_class = "success" if data.status.lower() in ["passed", "success"] else ""
        html += f"""
            <div class="evaluation-result {eval_result_class}">"""
        
        for key, value in data.details.items():
            if key not in ["agent_turns"]:
                html += f"""
                <div><strong>{key.replace('_', ' ').title()}:</strong> {value}</div>"""
        
        html += """
            </div>
        </div>"""
    
    if data.task_definition:
        html += f"""
        <div class="section">
            <h2 class="section-title">Task Definition</h2>
            <div class="task-intent">
                <strong>Intent:</strong> {data.intent}
            </div>"""
        
        if data.instantiation_dict:
            html += """
            <h3 class="section-subtitle">Parameters</h3>
            <div class="params-grid">"""
            for key, value in data.instantiation_dict.items():
                html += f"""
                <div class="param-key">{key}:</div>
                <div class="param-value">{value}</div>"""
            html += """
            </div>"""
        
        if data.eval_config:
            html += """
            <h3 class="section-subtitle">Evaluation Criteria</h3>
            <div class="info-grid">"""
            
            eval_types = data.eval_config.get("eval_types", [])
            if eval_types:
                html += f"""
                <div class="info-item">
                    <div class="info-label">Evaluation Type:</div>
                    <div class="info-value">{", ".join(eval_types)}</div>
                </div>"""
            
            reference_answers = data.eval_config.get("reference_answers", [])
            if reference_answers:
                html += f"""
                <div class="info-item">
                    <div class="info-label">Expected:</div>
                    <div class="info-value">{", ".join(str(a) for a in reference_answers)}</div>
                </div>"""
            
            html += """
            </div>"""
        
        html += """
        </div>"""
    
    if data.trajectory or data.ground_truth_trajectory:
        html += """
        <div class="section">
            <h2 class="section-title">Side-by-Side Comparison</h2>
            <div class="comparison-header">
                <div class="column-header ground-truth-header">Ground Truth Steps</div>
                <div class="column-header model-header">Model Trajectory</div>
            </div>"""
        
        model_steps = [s for s in data.trajectory if "step" in s]
        gt_steps = data.ground_truth_trajectory
        
        max_steps = max(len(gt_steps), len(model_steps)) if (gt_steps or model_steps) else 0
        
        for i in range(max_steps):
            html += """
            <div class="comparison-row">"""
            
            if i < len(gt_steps):
                html += """
                <div class="trajectory-column">"""
                html += format_ground_truth_step(gt_steps[i])
                html += """
                </div>"""
            else:
                html += """
                <div class="trajectory-column">
                    <div class="empty-step">No ground truth step</div>
                </div>"""
            
            if i < len(model_steps):
                html += """
                <div class="trajectory-column">"""
                html += format_trajectory_step(model_steps[i])
                html += """
                </div>"""
            else:
                html += """
                <div class="trajectory-column">
                    <div class="empty-step">No model step</div>
                </div>"""
            
            html += """
            </div>"""
        
        html += """
        </div>"""
    
    html += """
    </div>
</body>
</html>"""
    
    return html

