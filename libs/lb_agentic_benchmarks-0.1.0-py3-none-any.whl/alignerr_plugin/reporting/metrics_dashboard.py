from pathlib import Path


def generate_metrics_summary_html(results: list[dict]) -> str:
    """
    Generate HTML summary of quality metrics across all results.
    
    Args:
        results: List of result dicts with quality_metrics field
        
    Returns:
        HTML string with metrics dashboard
    """
    if not results:
        return "<p>No results available for metrics analysis.</p>"
    
    # Filter results that have quality metrics
    results_with_metrics = [r for r in results if r.get("quality_metrics")]
    
    if not results_with_metrics:
        return "<p>No quality metrics computed for these results.</p>"
    
    # Aggregate metrics
    num_eval_types = []
    num_reference_answers = []
    num_program_html_checks = []
    unique_urls = []
    unique_tools = []
    failure_modes = {}
    step_ratios = []
    
    for result in results_with_metrics:
        qm = result["quality_metrics"]
        
        rigor = qm.get("verification_rigor", {})
        num_eval_types.append(rigor.get("num_eval_types", 0))
        num_reference_answers.append(rigor.get("num_reference_answers", 0))
        num_program_html_checks.append(rigor.get("num_program_html_checks", 0))
        
        complexity = qm.get("interaction_complexity", {})
        unique_urls.append(complexity.get("unique_urls", 0))
        unique_tools.append(complexity.get("unique_tools", 0))
        
        failure_mode = qm.get("failure_mode", "unknown")
        failure_modes[failure_mode] = failure_modes.get(failure_mode, 0) + 1
        
        step_ratio = qm.get("reference_step_ratio", 0)
        if step_ratio > 0:
            step_ratios.append(step_ratio)
    
    # Calculate averages
    avg_eval_types = sum(num_eval_types) / len(num_eval_types) if num_eval_types else 0
    avg_reference_answers = sum(num_reference_answers) / len(num_reference_answers) if num_reference_answers else 0
    avg_program_html = sum(num_program_html_checks) / len(num_program_html_checks) if num_program_html_checks else 0
    avg_unique_urls = sum(unique_urls) / len(unique_urls) if unique_urls else 0
    avg_unique_tools = sum(unique_tools) / len(unique_tools) if unique_tools else 0
    avg_step_ratio = sum(step_ratios) / len(step_ratios) if step_ratios else 0
    
    html = f"""
    <div class="metrics-dashboard">
        <h2>Quality Metrics Dashboard</h2>
        
        <div class="metrics-summary">
            <div class="metric-card">
                <h3>Eval Types</h3>
                <div class="metric-value">{avg_eval_types:.1f}</div>
                <div class="metric-description">Avg evaluation mechanisms per task</div>
            </div>
            
            <div class="metric-card">
                <h3>Reference Answers</h3>
                <div class="metric-value">{avg_reference_answers:.1f}</div>
                <div class="metric-description">Avg reference answers per task</div>
            </div>
            
            <div class="metric-card">
                <h3>HTML Checks</h3>
                <div class="metric-value">{avg_program_html:.1f}</div>
                <div class="metric-description">Avg program_html checks per task</div>
            </div>
            
            <div class="metric-card">
                <h3>Unique URLs</h3>
                <div class="metric-value">{avg_unique_urls:.1f}</div>
                <div class="metric-description">Avg unique URLs visited</div>
            </div>
            
            <div class="metric-card">
                <h3>Unique Tools</h3>
                <div class="metric-value">{avg_unique_tools:.1f}</div>
                <div class="metric-description">Avg unique tools used</div>
            </div>
            
            <div class="metric-card">
                <h3>Reference Step Ratio</h3>
                <div class="metric-value">{avg_step_ratio:.2f}</div>
                <div class="metric-description">Actual steps / Reference steps</div>
                <div class="metric-details">
                    <div>&lt; 0.7: More efficient</div>
                    <div>0.7-1.3: Aligned</div>
                    <div>&gt; 1.3: Less efficient</div>
                </div>
            </div>
        </div>
        
        <div class="failure-modes">
            <h3>Failure Mode Distribution</h3>
            <table class="metrics-table">
                <thead>
                    <tr>
                        <th>Failure Mode</th>
                        <th>Count</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
    """
    
    total_failures = sum(failure_modes.values())
    for mode, count in sorted(failure_modes.items(), key=lambda x: x[1], reverse=True):
        percentage = (count / total_failures * 100) if total_failures > 0 else 0
        html += f"""
                    <tr>
                        <td><code>{mode}</code></td>
                        <td>{count}</td>
                        <td>{percentage:.1f}%</td>
                    </tr>
        """
    
    html += """
                </tbody>
            </table>
        </div>
    </div>
    
    <style>
        .metrics-dashboard {
            margin: 20px 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        
        .metrics-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .metric-card {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
        }
        
        .metric-card h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            font-weight: 600;
            color: #495057;
            text-transform: uppercase;
        }
        
        .metric-value {
            font-size: 36px;
            font-weight: 700;
            color: #212529;
            margin: 10px 0;
        }
        
        .metric-description {
            font-size: 13px;
            color: #6c757d;
            margin-bottom: 10px;
        }
        
        .metric-details {
            font-size: 12px;
            color: #868e96;
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px solid #dee2e6;
        }
        
        .metric-details div {
            margin: 3px 0;
        }
        
        .failure-modes {
            margin: 30px 0;
        }
        
        .failure-modes h3 {
            font-size: 18px;
            margin-bottom: 15px;
        }
        
        .metrics-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .metrics-table thead {
            background: #f8f9fa;
        }
        
        .metrics-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            color: #495057;
            border-bottom: 2px solid #dee2e6;
        }
        
        .metrics-table td {
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
        }
        
        .metrics-table tbody tr:last-child td {
            border-bottom: none;
        }
        
        .metrics-table code {
            background: #f1f3f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 12px;
            font-family: 'Monaco', 'Courier New', monospace;
        }
    </style>
    """
    
    return html


def generate_task_metrics_table(results: list[dict]) -> str:
    """
    Generate detailed table of per-task metrics.
    
    Args:
        results: List of result dicts with quality_metrics field
        
    Returns:
        HTML string with task metrics table
    """
    results_with_metrics = [r for r in results if r.get("quality_metrics")]
    
    if not results_with_metrics:
        return ""
    
    html = """
    <div class="task-metrics-table">
        <h3>Per-Task Metrics</h3>
        <table class="metrics-table">
            <thead>
                <tr>
                    <th>Task ID</th>
                    <th>Status</th>
                    <th>Eval Types</th>
                    <th>Ref Answers</th>
                    <th>HTML Checks</th>
                    <th>Unique URLs</th>
                    <th>Unique Tools</th>
                    <th>Steps (Actual/Ref)</th>
                    <th>Step Ratio</th>
                    <th>Failure Mode</th>
                </tr>
            </thead>
            <tbody>
    """
    
    for result in results_with_metrics:
        task_id = result.get("task_id", "unknown")
        status = result.get("status", "unknown")
        qm = result.get("quality_metrics", {})
        
        rigor = qm.get("verification_rigor", {})
        num_eval_types = rigor.get("num_eval_types", 0)
        num_ref_answers = rigor.get("num_reference_answers", 0)
        num_html_checks = rigor.get("num_program_html_checks", 0)
        
        complexity = qm.get("interaction_complexity", {})
        unique_urls = complexity.get("unique_urls", 0)
        unique_tools = complexity.get("unique_tools", 0)
        actual_steps = complexity.get("total_steps", 0)
        ref_steps = complexity.get("reference_steps", 0)
        
        step_ratio = qm.get("reference_step_ratio", 0)
        failure_mode = qm.get("failure_mode", "unknown")
        
        status_class = "success" if status == "success" else "failed"
        
        html += f"""
                <tr>
                    <td><code>{task_id}</code></td>
                    <td><span class="status-badge {status_class}">{status}</span></td>
                    <td>{num_eval_types}</td>
                    <td>{num_ref_answers}</td>
                    <td>{num_html_checks}</td>
                    <td>{unique_urls}</td>
                    <td>{unique_tools}</td>
                    <td>{actual_steps} / {ref_steps}</td>
                    <td>{step_ratio:.2f}</td>
                    <td><code>{failure_mode}</code></td>
                </tr>
        """
    
    html += """
            </tbody>
        </table>
    </div>
    
    <style>
        .task-metrics-table {
            margin: 30px 0;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .status-badge.success {
            background: #d4edda;
            color: #155724;
        }
        
        .status-badge.failed {
            background: #f8d7da;
            color: #721c24;
        }
    </style>
    """
    
    return html

