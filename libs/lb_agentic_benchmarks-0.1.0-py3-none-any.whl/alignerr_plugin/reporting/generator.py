from pathlib import Path
from alignerr_plugin.reporting.data_loader import load_report_data
from alignerr_plugin.reporting.html_template import render_html_report

def generate_html_report(result_dir: Path, project_root: Path, output_path: Path) -> None:
    data = load_report_data(result_dir, project_root)
    html_content = render_html_report(data)
    output_path.write_text(html_content)

