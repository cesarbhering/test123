import json
from pathlib import Path
from typing import Any

class ReportData:
    def __init__(
        self,
        result: dict[str, Any],
        trajectory: list[dict[str, Any]],
        ground_truth_trajectory: list[dict[str, Any]] | None = None,
        task_definition: dict[str, Any] | None = None,
    ):
        self.result = result
        self.trajectory = trajectory
        self.ground_truth_trajectory = ground_truth_trajectory or []
        self.task_definition = task_definition
        
        self.task_id = result.get("task_id", "")
        self.benchmark = result.get("benchmark", "")
        self.status = result.get("status", "unknown")
        self.metrics = result.get("metrics", {})
        self.details = result.get("details", {})
        self.timing_ms = result.get("timing_ms", {})
        self.artifacts = result.get("artifacts", [])
        self.quality_metrics = result.get("quality_metrics", {})
        
        if task_definition:
            self.intent = task_definition.get("intent", "")
            self.intent_template = task_definition.get("intent_template", "")
            self.instantiation_dict = task_definition.get("instantiation_dict", {})
            self.reference_action_sequence = task_definition.get("reference_action_sequence", {})
            self.eval_config = task_definition.get("eval", {})
        else:
            self.intent = ""
            self.intent_template = ""
            self.instantiation_dict = {}
            self.reference_action_sequence = {}
            self.eval_config = {}

def load_report_data(result_dir: Path, project_root: Path) -> ReportData:
    result_json = result_dir / "result.json"
    trajectory_json = result_dir / "trajectory.json"
    
    result = json.loads(result_json.read_text())
    trajectory_data = json.loads(trajectory_json.read_text())
    
    if isinstance(trajectory_data, dict):
        trajectory = trajectory_data.get("model_trajectory", [])
        ground_truth_trajectory = trajectory_data.get("ground_truth_trajectory", [])
    else:
        trajectory = trajectory_data
        ground_truth_trajectory = []
    
    task_definition = None
    task_id_from_result = result.get("task_id", "")
    benchmark = result.get("benchmark", "")
    
    if task_id_from_result and benchmark:
        parts = task_id_from_result.split("-")
        
        if benchmark in task_id_from_result:
            benchmark_idx = None
            for i, part in enumerate(parts):
                if part == benchmark and i > 0:
                    benchmark_idx = i
                    break
            
            if benchmark_idx is not None and len(parts) > benchmark_idx + 2:
                problem_id = parts[benchmark_idx + 1]
                task_file = parts[benchmark_idx + 2]
                
                problem_dir = project_root / "problems" / benchmark / problem_id
                task_path = problem_dir / "tasks" / f"{task_file}.json"
                
                if task_path.exists():
                    task_definition = json.loads(task_path.read_text())
    
    return ReportData(result, trajectory, ground_truth_trajectory, task_definition)

def load_validation_data(validation_dir: Path) -> dict | None:
    validation_json = validation_dir / "validation_result.json"
    if not validation_json.exists():
        return None
    return json.loads(validation_json.read_text())

def load_submission_data(result_dir: Path, project_root: Path) -> dict:
    tasks_data = []
    for item in result_dir.iterdir():
        if item.is_dir() and (item / "result.json").exists():
            result_json = item / "result.json"
            task_result = json.loads(result_json.read_text())
            tasks_data.append(task_result)
    
    return {
        "submission_id": result_dir.name,
        "tasks": tasks_data,
    }


def load_agent_aggregate_results(agents_data: dict[str, Path]) -> dict[str, dict]:
    """Load per-agent aggregate result.json files."""
    results = {}
    for agent_name, problem_dir in agents_data.items():
        aggregate_file = problem_dir / "result.json"
        if aggregate_file.exists():
            results[agent_name] = json.loads(aggregate_file.read_text())
        else:
            results[agent_name] = None
    return results


def load_all_task_results(agents_data: dict[str, Path]) -> list[dict]:
    """Load all task-level results across all agents."""
    all_results = []
    for agent_name, problem_dir in agents_data.items():
        for task_dir in problem_dir.iterdir():
            if not task_dir.is_dir():
                continue
            result_file = task_dir / "result.json"
            if not result_file.exists():
                continue
            result = json.loads(result_file.read_text())
            result["agent_name"] = agent_name
            result["task_dir_name"] = task_dir.name
            all_results.append(result)
    return all_results

