def render_submission_report(
    problem_id: str,
    validation_data: dict | None,
    agents_tasks: dict[str, list[dict]],
    radar_chart_html: str,
    validation_report_path: str | None = None,
    metrics_summary_html: str = "",
    metrics_table_html: str = "",
    failed_tasks_details: list[dict] | None = None,
) -> str:
    all_tasks = []
    for tasks in agents_tasks.values():
        all_tasks.extend(tasks)
    
    total_tasks = len(all_tasks)
    passed_tasks = sum(1 for task in all_tasks if task.get("status") in ["passed", "success"])
    failed_tasks = total_tasks - passed_tasks
    pass_rate = (passed_tasks / total_tasks * 100) if total_tasks > 0 else 0
    
    avg_metrics = {}
    if all_tasks:
        all_metric_keys = set()
        for task in all_tasks:
            all_metric_keys.update(task.get("metrics", {}).keys())
        
        for metric_key in all_metric_keys:
            values = []
            for task in all_tasks:
                val = task.get("metrics", {}).get(metric_key)
                if val is not None:
                    values.append(val)
            if values:
                avg_metrics[metric_key] = sum(values) / len(values)
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluation Report: {problem_id}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #1f2937;
            background: #f9fafb;
            padding: 2rem;
        }}
        
        .container {{
            max-width: 1800px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }}
        
        .header {{
            padding: 2rem;
            border-bottom: 2px solid #e5e7eb;
        }}
        
        .header h1 {{
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #111827;
        }}
        
        .summary-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }}
        
        .summary-card {{
            padding: 1.5rem;
            background: #f9fafb;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
        }}
        
        .summary-label {{
            font-size: 0.875rem;
            color: #6b7280;
            margin-bottom: 0.5rem;
        }}
        
        .summary-value {{
            font-size: 1.75rem;
            font-weight: 700;
            color: #111827;
        }}
        
        .section {{
            padding: 2rem;
            border-bottom: 1px solid #e5e7eb;
        }}
        
        .section:last-child {{
            border-bottom: none;
        }}
        
        .section-title {{
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #111827;
        }}
        
        .validation-status {{
            padding: 1.5rem;
            border-radius: 6px;
            margin-bottom: 1rem;
        }}
        
        .validation-status.valid {{
            background: #f0fdf4;
            border-left: 4px solid #22c55e;
        }}
        
        .validation-status.invalid {{
            background: #fef2f2;
            border-left: 4px solid #ef4444;
        }}
        
        .validation-link {{
            display: inline-block;
            margin-top: 0.75rem;
            padding: 0.5rem 1rem;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 4px;
            text-decoration: none;
            color: #3b82f6;
            font-weight: 600;
            font-size: 0.875rem;
        }}
        
        .validation-link:hover {{
            background: #f9fafb;
        }}
        
        .chart-container {{
            margin-top: 1.5rem;
            padding: 1.5rem;
            background: #f9fafb;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
        }}
        
        .tasks-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }}
        
        .tasks-table th {{
            background: #f3f4f6;
            padding: 0.75rem 1rem;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 2px solid #e5e7eb;
        }}
        
        .tasks-table td {{
            padding: 0.75rem 1rem;
            border-bottom: 1px solid #e5e7eb;
        }}
        
        .tasks-table tr:hover {{
            background: #f9fafb;
        }}
        
        .status-badge {{
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 4px;
            font-weight: 600;
            font-size: 0.75rem;
            text-transform: uppercase;
        }}
        
        .status-badge.success {{
            background: #22c55e;
            color: white;
        }}
        
        .status-badge.failed {{
            background: #ef4444;
            color: white;
        }}
        
        .task-link {{
            color: #3b82f6;
            text-decoration: none;
            font-weight: 500;
        }}
        
        .task-link:hover {{
            text-decoration: underline;
        }}
        
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 0.5rem;
            margin-top: 1rem;
        }}
        
        .metric-chip {{
            padding: 0.5rem 0.75rem;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 4px;
            font-size: 0.875rem;
        }}
        
        .metric-key {{
            font-weight: 600;
            color: #6b7280;
            margin-right: 0.5rem;
        }}
        
        .metric-value {{
            color: #111827;
        }}
        
        .failure-card {{
            padding: 1.5rem;
            background: #fef2f2;
            border-radius: 6px;
            border-left: 4px solid #ef4444;
            margin-bottom: 1rem;
        }}
        
        .failure-header {{
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }}
        
        .failure-title {{
            font-weight: 700;
            font-size: 1.125rem;
            color: #991b1b;
        }}
        
        .failure-agent {{
            font-size: 0.875rem;
            color: #6b7280;
            background: white;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
        }}
        
        .failure-detail {{
            margin-bottom: 0.75rem;
        }}
        
        .failure-label {{
            font-weight: 600;
            color: #374151;
            font-size: 0.875rem;
            margin-bottom: 0.25rem;
        }}
        
        .failure-value {{
            color: #1f2937;
            font-size: 0.9375rem;
            line-height: 1.5;
        }}
        
        .failure-mode-badge {{
            display: inline-block;
            padding: 0.25rem 0.75rem;
            background: #fecaca;
            color: #991b1b;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }}
        
        .agent-summary-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }}
        
        .agent-card {{
            padding: 1.5rem;
            background: #f9fafb;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
        }}
        
        .agent-card.success {{
            border-left: 4px solid #22c55e;
        }}
        
        .agent-card.partial {{
            border-left: 4px solid #f59e0b;
        }}
        
        .agent-card.failed {{
            border-left: 4px solid #ef4444;
        }}
        
        .agent-name {{
            font-weight: 700;
            font-size: 1.125rem;
            color: #111827;
            margin-bottom: 0.75rem;
        }}
        
        .agent-stats {{
            display: flex;
            gap: 1.5rem;
        }}
        
        .agent-stat {{
            text-align: center;
        }}
        
        .agent-stat-value {{
            font-size: 1.5rem;
            font-weight: 700;
        }}
        
        .agent-stat-label {{
            font-size: 0.75rem;
            color: #6b7280;
            text-transform: uppercase;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Evaluation Report: {problem_id}</h1>
            <div class="summary-grid">
                <div class="summary-card">
                    <div class="summary-label">Total Tasks</div>
                    <div class="summary-value">{total_tasks}</div>
                </div>
                <div class="summary-card">
                    <div class="summary-label">Passed</div>
                    <div class="summary-value" style="color: #22c55e;">{passed_tasks}</div>
                </div>
                <div class="summary-card">
                    <div class="summary-label">Failed</div>
                    <div class="summary-value" style="color: #ef4444;">{failed_tasks}</div>
                </div>
                <div class="summary-card">
                    <div class="summary-label">Pass Rate</div>
                    <div class="summary-value">{pass_rate:.1f}%</div>
                </div>"""
    
    for metric_key, metric_value in avg_metrics.items():
        metric_label = metric_key.replace('_', ' ').title()
        html += f"""
                <div class="summary-card">
                    <div class="summary-label">Avg {metric_label}</div>
                    <div class="summary-value">{metric_value:.2f}</div>
                </div>"""
    
    html += """
            </div>
        </div>"""
    
    agent_summaries = {}
    for agent_name, tasks in agents_tasks.items():
        passed = sum(1 for t in tasks if t.get("status") in ["passed", "success"])
        failed = len(tasks) - passed
        rate = (passed / len(tasks) * 100) if tasks else 0
        agent_summaries[agent_name] = {"passed": passed, "failed": failed, "total": len(tasks), "rate": rate}
    
    html += """
        <div class="section">
            <h2 class="section-title">Agent Performance Summary</h2>
            <div class="agent-summary-grid">"""
    
    for agent_name, stats in agent_summaries.items():
        rate = stats["rate"]
        status_class = "success" if rate >= 80 else "partial" if rate >= 50 else "failed"
        html += f"""
                <div class="agent-card {status_class}">
                    <div class="agent-name">{agent_name}</div>
                    <div class="agent-stats">
                        <div class="agent-stat">
                            <div class="agent-stat-value" style="color: #22c55e;">{stats["passed"]}</div>
                            <div class="agent-stat-label">Passed</div>
                        </div>
                        <div class="agent-stat">
                            <div class="agent-stat-value" style="color: #ef4444;">{stats["failed"]}</div>
                            <div class="agent-stat-label">Failed</div>
                        </div>
                        <div class="agent-stat">
                            <div class="agent-stat-value">{rate:.0f}%</div>
                            <div class="agent-stat-label">Pass Rate</div>
                        </div>
                    </div>
                </div>"""
    
    html += """
            </div>
        </div>"""
    
    if validation_data and validation_report_path:
        validation_status = validation_data.get("status", "unknown")
        status_class = "valid" if validation_status == "valid" else "invalid"
        html += f"""
        <div class="section">
            <h2 class="section-title">Validation Status</h2>
            <div class="validation-status {status_class}">
                <div style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem;">
                    Status: {validation_status.upper()}
                </div>
                <div style="color: #6b7280; font-size: 0.875rem;">
                    Timestamp: {validation_data.get("timestamp", "N/A")}
                </div>
                <a href="{validation_report_path}" class="validation-link">View Full Validation Report →</a>
            </div>
        </div>"""
    
    if metrics_summary_html:
        html += f"""
        <div class="section">
            <h2 class="section-title">Quality Metrics</h2>
            {metrics_summary_html}
        </div>"""
    
    html += f"""
        <div class="section">
            <h2 class="section-title">Agent Performance Comparison</h2>
            {radar_chart_html}
        </div>"""
    
    if metrics_table_html:
        html += f"""
        <div class="section">
            {metrics_table_html}
        </div>"""
    
    html += """
        <div class="section">
            <h2 class="section-title">Task Results</h2>
            <table class="tasks-table">
                <thead>
                    <tr>
                        <th>Agent</th>
                        <th>Task</th>
                        <th>Status</th>
                        <th>Metrics</th>
                        <th>Report</th>
                    </tr>
                </thead>
                <tbody>"""
    
    for agent_name, tasks in agents_tasks.items():
        for task in tasks:
            task_id = task.get("task_id", "unknown")
            task_name = task_id.split("-")[-1] if "-" in task_id else task_id
            status = task.get("status", "unknown")
            status_class = "success" if status in ["passed", "success"] else "failed"
            metrics = task.get("metrics", {})
            
            html += f"""
                    <tr>
                        <td style="font-weight: 500;">{agent_name}</td>
                        <td style="font-weight: 500;">{task_name}</td>
                        <td><span class="status-badge {status_class}">{status}</span></td>
                        <td>"""
            
            if metrics:
                html += '<div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">'
                for key, value in metrics.items():
                    html += f'<span class="metric-chip"><span class="metric-key">{key}:</span><span class="metric-value">{value}</span></span>'
                html += '</div>'
            else:
                html += '<span style="color: #9ca3af;">No metrics</span>'
            
            html += f"""
                        </td>
                        <td><a href="{agent_name}/{problem_id}/{task_name}/report.html" class="task-link">View Report →</a></td>
                    </tr>"""
    
    html += """
                </tbody>
            </table>
        </div>"""
    
    if failed_tasks_details:
        html += """
        <div class="section">
            <h2 class="section-title">Failed Task Analysis</h2>"""
        
        for failure in failed_tasks_details:
            agent_name = failure.get("agent_name", "unknown")
            task_name = failure.get("task_name", "unknown")
            intent = failure.get("intent", "N/A")
            evaluation = failure.get("evaluation", "N/A")
            failure_mode = failure.get("failure_mode", "unknown")
            final_url = failure.get("final_url", "")
            
            html += f"""
            <div class="failure-card">
                <div class="failure-header">
                    <div class="failure-title">{task_name}</div>
                    <div class="failure-agent">{agent_name}</div>
                </div>
                <div class="failure-detail">
                    <div class="failure-label">Intent</div>
                    <div class="failure-value">{intent}</div>
                </div>
                <div class="failure-detail">
                    <div class="failure-label">Evaluation Result</div>
                    <div class="failure-value">{evaluation}</div>
                </div>
                <div class="failure-detail">
                    <div class="failure-label">Failure Mode</div>
                    <span class="failure-mode-badge">{failure_mode}</span>
                </div>"""
            
            if final_url:
                html += f"""
                <div class="failure-detail">
                    <div class="failure-label">Final URL</div>
                    <div class="failure-value"><code>{final_url}</code></div>
                </div>"""
            
            html += """
            </div>"""
        
        html += """
        </div>"""
    
    html += """
    </div>
</body>
</html>"""
    
    return html

