import plotly.graph_objects as go
import plotly.io as pio
import hashlib

def generate_radar_chart(agents_radar_data: list[dict], metric_names: list[str], title: str = "Agent Performance Comparison") -> str:
    if not agents_radar_data or not metric_names:
        return "<div>No data available for chart</div>"
    
    traces = []
    for agent_data in agents_radar_data:
        agent_name = agent_data.get("agent_name", "unknown")
        scores = agent_data.get("scores", [])
        hover_text = agent_data.get("hover_text", [])
        
        trace = go.Scatterpolar(
            r=scores,
            theta=[name.replace('_', ' ').title() for name in metric_names],
            fill='toself',
            name=agent_name,
            text=hover_text,
            hovertemplate='<b>%{text}</b><br>Normalized Score: %{r:.2f}<extra></extra>',
        )
        traces.append(trace)
    
    fig = go.Figure(data=traces)
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 1]
            )
        ),
        showlegend=True,
        title=title,
        height=600,
    )
    
    chart_id = f"radar-chart-{hashlib.md5(title.encode()).hexdigest()[:8]}"
    html_div = pio.to_html(fig, include_plotlyjs='cdn', div_id=chart_id, full_html=False)
    return html_div

