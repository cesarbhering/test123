import base64

from .base import BaseStage


class PatchStage(BaseStage):
    def __init__(self, patch_key: str, patch_name: str):
        self.patch_key = patch_key
        self.patch_name = patch_name
    
    def _run(self, container, workspace_path, problem_data: dict) -> tuple[bool, list[str]]:
        patch = problem_data.get(self.patch_key, "")
        if not patch:
            return False, [f"No {self.patch_name} provided"]
        
        patch_b64 = base64.b64encode(patch.encode('utf-8')).decode('ascii')
        
        exit_code, check_output = container.exec_run(
            ["sh", "-c", f"echo {patch_b64} | base64 -d | git apply --check"],
        )
        
        if exit_code != 0:
            return False, [f"{self.patch_name} does not apply cleanly", check_output.decode('utf-8', errors='ignore')]
        
        exit_code, apply_output = container.exec_run(
            ["sh", "-c", f"echo {patch_b64} | base64 -d | git apply"],
        )
        
        if exit_code != 0:
            return False, [f"Failed to apply {self.patch_name}: {apply_output.decode('utf-8', errors='ignore')}"]
        
        return True, []

