from .base import BaseStage


class EnvironmentSetupStage(BaseStage):
    def _run(self, container, workspace_path, problem_data: dict) -> tuple[bool, list[str]]:
        env_setup_commit = problem_data.get("environment_setup_commit")
        if not env_setup_commit:
            return False, ["Missing required field: environment_setup_commit"]
        
        setup_script = problem_data.get("environment_setup_script")
        if not setup_script:
            return False, ["Missing required field: environment_setup_script"]
        
        # Add workspace to git safe.directory to avoid ownership issues in Docker
        container.exec_run(["git", "config", "--global", "--add", "safe.directory", "/workspace"])
        
        container.exec_run(["git", "reset", "--hard"])
        container.exec_run(["git", "clean", "-fdx"])
        
        exit_code, output = container.exec_run(["git", "checkout", env_setup_commit])
        if exit_code != 0:
            return False, [f"Failed to checkout environment_setup_commit: {output.decode('utf-8', errors='ignore')}"]
        
        current_commit = self._get_commit(container)
        if not current_commit.startswith(env_setup_commit[:7]):
            return False, [f"Commit mismatch. Expected: {env_setup_commit}, Got: {current_commit}"]
        
        exit_code, output = container.exec_run(["bash", "-c", setup_script])
        if exit_code != 0:
            return False, [f"Environment setup failed: {output.decode('utf-8', errors='ignore')}"]
        
        return True, []

