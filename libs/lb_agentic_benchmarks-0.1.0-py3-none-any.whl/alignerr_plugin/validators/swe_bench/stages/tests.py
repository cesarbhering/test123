from .base import BaseStage


class TestStage(BaseStage):
    def __init__(self, should_fail: bool = False):
        self.should_fail = should_fail
    
    def _run(self, container, workspace_path, problem_data: dict) -> tuple[bool, list[str]]:
        test_script = problem_data.get("test_script", "")
        if not test_script:
            return False, ["No test_script provided"]
        
        exit_code, output = container.exec_run(["bash", "-c", test_script])
        output_str = output.decode("utf-8", errors="ignore")
        
        if self.should_fail:
            if exit_code == 0:
                return False, ["Tests passed but should have failed", f"Output: {output_str}"]
            return True, [f"Tests correctly failed with exit code {exit_code}"]
        else:
            if exit_code != 0:
                return False, [f"Tests failed with exit code {exit_code}", f"Output: {output_str}"]
            return True, []

