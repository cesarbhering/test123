import time
from abc import ABC, abstractmethod

from alignerr.schemas import StageResult


class BaseStage(ABC):
    def execute(self, container, workspace_path, problem_data: dict) -> StageResult:
        start = time.time()
        try:
            passed, issues = self._run(container, workspace_path, problem_data)
            duration_ms = int((time.time() - start) * 1000)
            return StageResult(passed=passed, issues=issues, duration_ms=duration_ms)
        except Exception as e:
            duration_ms = int((time.time() - start) * 1000)
            return StageResult(passed=False, issues=[f"Exception: {str(e)}"], duration_ms=duration_ms)

    @abstractmethod
    def _run(self, container, workspace_path, problem_data: dict) -> tuple[bool, list[str]]:
        pass
    
    @staticmethod
    def _get_commit(container) -> str:
        _, output = container.exec_run(["git", "rev-parse", "HEAD"])
        return output.decode("utf-8", errors="ignore").strip()

