from .base import BaseStage


class CheckoutStage(BaseStage):
    def _run(self, container, workspace_path, problem_data: dict) -> tuple[bool, list[str]]:
        base_commit = problem_data.get("base_commit")
        if not base_commit:
            return False, ["Missing required field: base_commit"]
        
        exit_code, _ = container.exec_run(["git", "fetch", "--depth", "1", "origin", base_commit])
        if exit_code != 0:
            return False, ["Failed to fetch base_commit"]
        
        exit_code, output = container.exec_run(["git", "checkout", base_commit])
        if exit_code != 0:
            return False, [f"Failed to checkout base_commit: {output.decode('utf-8', errors='ignore')}"]
        
        current_commit = self._get_commit(container)
        if not current_commit.startswith(base_commit[:7]):
            return False, [f"Commit mismatch. Expected: {base_commit}, Got: {current_commit}"]
        
        return True, []

