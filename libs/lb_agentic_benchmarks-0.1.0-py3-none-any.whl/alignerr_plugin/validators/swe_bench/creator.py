import json
from pathlib import Path

import typer
from rich.console import Console

console = Console()


class SWEBenchCreator:
    def collect_inputs(self) -> dict:
        console.print("\n[bold]Repository:[/bold]")
        repo = typer.prompt("Repo (e.g., django/django)", type=str)
        
        if "/" not in repo:
            console.print("[red]Invalid repo format. Use: owner/repo[/red]")
            raise typer.Exit(code=1)
        
        console.print("\n[bold]Pull Request:[/bold]")
        pr_number = typer.prompt("PR number", type=int)
        
        console.print("\n[bold]Git Information:[/bold]")
        base_commit = typer.prompt("Base commit (40-char hash)", type=str)
        
        if len(base_commit) != 40 or not all(c in "0123456789abcdef" for c in base_commit):
            console.print("[red]Invalid commit hash. Must be 40 hexadecimal characters.[/red]")
            raise typer.Exit(code=1)
        
        console.print("\n[bold]Docker Configuration:[/bold]")
        docker_image = typer.prompt("Docker image", type=str, default="python:3.11-bullseye")
        
        return {
            "repo": repo,
            "pr_number": pr_number,
            "base_commit": base_commit,
            "docker_image": docker_image
        }
    
    def create_structure(self, output_dir: Path, inputs: dict) -> Path:
        repo = inputs["repo"]
        pr_number = inputs["pr_number"]
        base_commit = inputs["base_commit"]
        docker_image = inputs["docker_image"]
        
        repo_name = repo.replace("/", "__")
        instance_id = f"{repo_name}-{pr_number}"
        
        problem_dir = output_dir / "swe_bench" / instance_id
        problem_dir.mkdir(parents=True, exist_ok=True)
        
        console.print(f"\n[bold green]Creating problem structure:[/bold green]")
        console.print(f"  Location: {problem_dir}")
        console.print(f"  Instance ID: {instance_id}")
        
        metadata = {
            "benchmark": "swe_bench",
            "repo_url": f"https://github.com/{repo}.git",
            "commit": base_commit,
            "docker_image": docker_image,
            "problem_data": {
                "repo": repo,
                "instance_id": instance_id,
                "base_commit": base_commit,
                "FAIL_TO_PASS": "[]",
                "PASS_TO_PASS": "[]",
                "environment_setup_commit": base_commit,
            }
        }
        
        (problem_dir / "metadata.json").write_text(json.dumps(metadata, indent=2))
        console.print("  ✓ Created metadata.json")
        
        (problem_dir / "problem.txt").write_text(
            f"# Problem Description\n\n"
            f"Issue from: {repo}#{pr_number}\n\n"
            f"TODO: Add problem description here\n"
        )
        console.print("  ✓ Created problem.txt")
        
        (problem_dir / "setup.sh").write_text(
            "#!/bin/bash\n"
            "# TODO: Add setup commands here\n"
            "# Example:\n"
            "# pip install -q -r requirements.txt\n"
            "# pip install -q -e .\n"
            "exit 1\n"
        )
        console.print("  ✓ Created setup.sh")
        
        (problem_dir / "test.sh").write_text(
            "#!/bin/bash\n"
            "# TODO: Add test command here\n"
            "# Example: python -m pytest tests/test_file.py::test_function -xvs\n"
            "exit 1\n"
        )
        console.print("  ✓ Created test.sh")
        
        (problem_dir / "solution.patch").write_text(
            "# TODO: Add solution patch here\n"
            "# This patch should contain the fix for the issue\n"
        )
        console.print("  ✓ Created solution.patch")
        
        (problem_dir / "test.patch").write_text(
            "# TODO: Add test patch here\n"
            "# This patch should contain new tests that fail before the fix\n"
        )
        console.print("  ✓ Created test.patch")
        
        console.print(f"\n[bold green]✓ Problem structure created successfully![/bold green]")
        console.print(f"\n[bold]Next steps:[/bold]")
        console.print(f"1. Edit {problem_dir}/problem.txt with the problem description")
        console.print(f"2. Edit {problem_dir}/test.sh with the test command")
        console.print(f"3. Add the solution patch to {problem_dir}/solution.patch")
        console.print(f"4. Add the test patch to {problem_dir}/test.patch")
        console.print(f"5. Update metadata.json with FAIL_TO_PASS and PASS_TO_PASS test lists")
        console.print(f"\n[bold]Then validate:[/bold]")
        console.print(f"  alignerr validate --problem-dir {problem_dir}")
        
        return problem_dir

