import json
import time
from pathlib import Path

import docker

from alignerr_plugin.materialize import materialize_repo
from alignerr.schemas import (
    StageResult,
    ValidationResult,
)

from .stages import CheckoutStage, EnvironmentSetupStage, PatchStage, TestStage


class SWEBenchValidator:
    def load_submission(self, problem_dir: Path) -> dict:
        metadata_path = problem_dir / "metadata.json"
        return json.loads(metadata_path.read_text())
    
    def get_problem_id(self, problem_data: dict) -> str:
        return problem_data.get("instance_id", "unknown")
    
    def validate(
        self,
        problem_dir: Path,
        results_dir: Path,
        project_root: Path,
    ) -> ValidationResult:
        submission_data = self.load_submission(problem_dir)
        problem_data = submission_data.get("problem_data", {})
        problem_id = self.get_problem_id(problem_data)
        
        repo_url = submission_data.get("repo_url")
        docker_image = submission_data.get("docker_image")
        env_setup_commit = problem_data.get("environment_setup_commit")
        
        results_dir.mkdir(parents=True, exist_ok=True)
        
        stages: dict[str, StageResult] = {}
        
        if not env_setup_commit:
            stages["schema_validation"] = StageResult(
                passed=False,
                issues=["environment_setup_commit is required in problem_data"],
                duration_ms=0
            )
            return self._build_result(problem_id, stages, "invalid", problem_data)

        cache_root = project_root / ".cache"
        
        try:
            workspace_path = materialize_repo(repo_url, env_setup_commit, cache_root)
        except Exception as e:
            stages["schema_validation"] = StageResult(passed=True, issues=[], duration_ms=0)
            stages["repo_ready"] = StageResult(
                passed=False,
                issues=[
                    f"Failed to clone/checkout repository at commit {env_setup_commit}",
                    f"Error: {str(e)}",
                    "Please verify:",
                    "1. The repository URL is correct",
                    "2. The environment_setup_commit exists in the repository",
                    "3. The commit hash is the full 40-character SHA"
                ],
                duration_ms=0
            )
            return self._build_result(problem_id, stages, "invalid", problem_data)

        container_name = f"validator-{problem_id}-{int(time.time())}"
        client = docker.from_env()
        container = None

        try:
            container = client.containers.run(
                docker_image,
                command="sleep 3600",
                name=container_name,
                detach=True,
                volumes={str(workspace_path.resolve()): {"bind": "/workspace", "mode": "rw"}},
                working_dir="/workspace",
                remove=False,
            )
            print(f"Started container: {container.short_id}")

            result = self._run_validation_stages(container, workspace_path, problem_data)
            return result

        except Exception as e:
            stages["schema_validation"] = StageResult(passed=True, issues=[], duration_ms=0)
            stages["repo_ready"] = StageResult(passed=True, issues=[], duration_ms=0)
            stages["environment_setup"] = StageResult(
                passed=False,
                issues=[
                    f"Docker container failed to start or crashed",
                    f"Error: {str(e)}",
                    "Please verify:",
                    "1. The docker_image is valid and accessible",
                    "2. Docker is running and has sufficient resources"
                ],
                duration_ms=0
            )
            return self._build_result(problem_id, stages, "invalid", problem_data)
        finally:
            if container:
                container.remove(force=True)
                print(f"Cleaned up container: {container_name}")

    def _run_validation_stages(self, container, workspace_path: Path, problem_data: dict) -> ValidationResult:
        problem_id = problem_data.get("instance_id", "unknown")
        
        stages: dict[str, StageResult] = {}
        stages["schema_validation"] = StageResult(passed=True, issues=[], duration_ms=0)
        stages["repo_ready"] = StageResult(passed=True, issues=[], duration_ms=0)

        print("=== Stage 1: Environment Setup ===")
        stages["environment_setup"] = EnvironmentSetupStage().execute(container, workspace_path, problem_data)
        if not stages["environment_setup"].passed:
            return self._build_result(problem_id, stages, "invalid", problem_data)

        print("=== Stage 2: Checkout base commit ===")
        checkout_result = CheckoutStage().execute(container, workspace_path, problem_data)
        if not checkout_result.passed:
            stages["test_patch_applies"] = checkout_result
            return self._build_result(problem_id, stages, "invalid", problem_data)

        print("=== Stage 3: Apply test patch ===")
        stages["test_patch_applies"] = PatchStage("test_patch", "test_patch").execute(container, workspace_path, problem_data)
        if not stages["test_patch_applies"].passed:
            return self._build_result(problem_id, stages, "invalid", problem_data)

        print("=== Stage 4: Run tests (should fail) ===")
        stages["tests_fail_before_fix"] = TestStage(should_fail=True).execute(container, workspace_path, problem_data)
        if not stages["tests_fail_before_fix"].passed:
            return self._build_result(problem_id, stages, "invalid", problem_data)

        print("=== Stage 5: Apply solution patch ===")
        stages["solution_patch_applies"] = PatchStage("patch", "solution_patch").execute(container, workspace_path, problem_data)
        if not stages["solution_patch_applies"].passed:
            return self._build_result(problem_id, stages, "invalid", problem_data)

        print("=== Stage 6: Run tests (should pass) ===")
        stages["tests_pass_after_fix"] = TestStage(should_fail=False).execute(container, workspace_path, problem_data)
        if not stages["tests_pass_after_fix"].passed:
            return self._build_result(problem_id, stages, "invalid", problem_data)

        return self._build_result(problem_id, stages, "valid", problem_data)

    def _build_result(self, problem_id: str, stages: dict[str, StageResult], status: str, problem_data: dict) -> ValidationResult:
        patch = problem_data.get("patch", "")
        files_changed = patch.count("diff --git")
        lines_changed = sum(1 for line in patch.split("\n") if line.startswith(("+", "-")) and not line.startswith(("+++", "---")))

        return ValidationResult(
            problem_id=problem_id,
            benchmark="swe_bench",
            status=status,
            stages=stages,
            metadata={
                "repo": problem_data.get("repo", "unknown"),
                "commit": problem_data.get("base_commit", "unknown"),
                "files_changed": files_changed,
                "lines_changed": lines_changed,
            },
        )

