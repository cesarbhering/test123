"""
Shared metric computation utilities for WebArena validators.

NOTE: This module is intentionally separate from evaluators/webarena/metrics.py
because validators must be self-contained and run client-side without evaluator
dependencies. Any changes here should be synced with the evaluator version.
"""

from .task_schema import WebArenaTask


def compute_verification_rigor(task: WebArenaTask) -> dict:
    """
    Compute verification rigor metrics based on evaluation configuration.
    
    Returns dict with counts of evaluation mechanisms:
    - num_eval_types: number of evaluation types
    - num_reference_answers: number of reference answers
    - num_program_html_checks: number of HTML validation checks
    - has_url_validation: whether URL matching is configured
    - eval_types: list of evaluation types used
    """
    eval_config = task.eval
    
    eval_types = eval_config.eval_types
    reference_answers = eval_config.reference_answers
    program_html = eval_config.program_html
    reference_url = eval_config.reference_url
    
    return {
        "num_eval_types": len(eval_types),
        "num_reference_answers": len(reference_answers),
        "num_program_html_checks": len(program_html),
        "has_url_validation": "url_match" in eval_types and bool(reference_url),
        "eval_types": eval_types,
    }

