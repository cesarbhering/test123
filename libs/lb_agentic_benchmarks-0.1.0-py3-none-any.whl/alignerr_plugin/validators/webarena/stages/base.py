import time
from abc import ABC, abstractmethod
from pathlib import Path

from alignerr.schemas import StageResult


class BaseStage(ABC):
    def execute(self, problem_dir: Path, problem_data: dict, **kwargs) -> StageResult:
        start = time.time()
        passed, issues = self._run(problem_dir, problem_data, **kwargs)
        duration_ms = int((time.time() - start) * 1000)
        return StageResult(passed=passed, issues=issues, duration_ms=duration_ms)

    @abstractmethod
    def _run(self, problem_dir: Path, problem_data: dict, **kwargs) -> tuple[bool, list[str]]:
        pass

