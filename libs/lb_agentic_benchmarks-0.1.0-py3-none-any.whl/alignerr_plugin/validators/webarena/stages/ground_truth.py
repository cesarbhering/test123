import json
from pathlib import Path

from code_tools.logging_config import get_logger
from ..playwright_runner import PlaywrightRunner
from ..task_schema import WebArenaTask
from .base import BaseStage

logger = get_logger(__name__)


class GroundTruthStage(BaseStage):
    def _run(self, problem_dir: Path, problem_data: dict, **kwargs) -> tuple[bool, list[str]]:
        compose_project = kwargs["compose_project"]
        tasks_dir = problem_dir / "tasks"

        logger.info(f"🔍 Ground Truth Validation")
        logger.info(f"  Compose project: {compose_project}")
        logger.info(f"  Problem directory: {problem_dir}")
        logger.info(f"  Tasks directory: {tasks_dir}")
        logger.info(f"  Number of tasks: {len(problem_data['tasks'])}")

        runner = PlaywrightRunner(compose_project)
        issues = []

        for idx, task_file in enumerate(problem_data["tasks"], 1):
            task_path = tasks_dir / task_file

            logger.info(f"\n📋 Task {idx}/{len(problem_data['tasks'])}: {task_file}")
            logger.debug(f"  Task path: {task_path}")
            logger.debug(f"  Task exists: {task_path.exists()}")

            with open(task_path) as f:
                task_data = json.load(f)

            task = WebArenaTask.model_validate(task_data)
            logger.debug(f"  Task ID: {task.task_id}")
            logger.debug(f"  Start URL: {task.start_url}")
            logger.debug(f"  Require login: {task.require_login}")
            logger.debug(f"  Action sequence length: {len(task.reference_action_sequence.action_sequence)}")

            logger.info(f"\n🎬 Executing task {task.task_id}...")
            try:
                runner.execute_task(task, problem_dir)
                logger.info(f"  ✅ Task {task.task_id} passed")
            except Exception as e:
                error_msg = f"Task {task_file} failed: {str(e)}"
                logger.error(f"  ❌ {error_msg}")
                issues.append(error_msg)

        if issues:
            logger.error(f"\n❌ {len(issues)} task(s) failed validation")
            return False, issues

        logger.success(f"\n✅ All {len(problem_data['tasks'])} tasks validated successfully")
        return True, []
