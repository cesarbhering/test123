import json
from pathlib import Path

from code_tools.logging_config import get_logger
from ..task_schema import WebArenaTask
from ..metrics_utils import compute_verification_rigor
from .base import BaseStage

logger = get_logger(__name__)


MIN_EVAL_TYPES = 1
MIN_REFERENCE_ANSWERS = 1


class MetricsValidationStage(BaseStage):
    def _run(self, problem_dir: Path, problem_data: dict, **kwargs) -> tuple[bool, list[str]]:
        tasks_dir = problem_dir / "tasks"
        
        logger.info(f"🔍 Task Quality Metrics Validation")
        logger.info(f"  Problem directory: {problem_dir}")
        logger.info(f"  Tasks directory: {tasks_dir}")
        logger.info(f"  Number of tasks: {len(problem_data['tasks'])}")
        logger.info(f"  Minimum eval types: {MIN_EVAL_TYPES}")
        logger.info(f"  Minimum reference answers: {MIN_REFERENCE_ANSWERS}")
        
        errors = []
        low_quality_tasks = []
        
        for idx, task_file in enumerate(problem_data["tasks"], 1):
            task_path = tasks_dir / task_file
            
            logger.info(f"\n📋 Task {idx}/{len(problem_data['tasks'])}: {task_file}")
            
            with open(task_path) as f:
                task_data = json.load(f)
            
            task = WebArenaTask.model_validate(task_data)
            
            # Compute verification rigor
            rigor_metrics = compute_verification_rigor(task)
            
            task_errors = []
            if rigor_metrics['num_eval_types'] < MIN_EVAL_TYPES:
                task_errors.append(f"num_eval_types={rigor_metrics['num_eval_types']} < {MIN_EVAL_TYPES}")
            
            if rigor_metrics['num_reference_answers'] < MIN_REFERENCE_ANSWERS and rigor_metrics['num_program_html_checks'] == 0:
                task_errors.append(f"num_reference_answers={rigor_metrics['num_reference_answers']} < {MIN_REFERENCE_ANSWERS} and no HTML checks")
            
            if task_errors:
                logger.warning(f"  Eval types: {rigor_metrics['eval_types']}")
                logger.warning(f"  Reference answers: {rigor_metrics['num_reference_answers']}")
                logger.warning(f"  HTML checks: {rigor_metrics['num_program_html_checks']}")
                error_msg = f"Task {task_file} failed quality checks: {', '.join(task_errors)}"
                logger.warning(f"  ⚠️  {error_msg}")
                low_quality_tasks.append((task_file, task_errors))
                errors.append(error_msg)
            else:
                logger.info(f"  ✅ {rigor_metrics['eval_types']} with {rigor_metrics['num_reference_answers']} ref answers, {rigor_metrics['num_program_html_checks']} HTML checks")
        
        if low_quality_tasks:
            logger.warning(f"\n⚠️  Found {len(low_quality_tasks)} task(s) with insufficient verification:")
            for task_file, task_errors in low_quality_tasks:
                logger.warning(f"  - {task_file}: {', '.join(task_errors)}")
            logger.warning("\nRecommendations to improve verification:")
            logger.warning("  1. Add multiple eval_types (e.g., both url_match and program_html)")
            logger.warning("  2. Use program_html checks for robust validation")
            logger.warning("  3. Provide reference_answers or HTML checks")
            logger.warning("  4. Add reference_url validation for url_match")
            return False, errors
        
        logger.success(f"\n✅ All {len(problem_data['tasks'])} tasks passed quality metrics validation")
        return True, []

