import json
from pathlib import Path

import yaml

from ..task_schema import WebArenaTask, WebArenaProblemData
from .base import BaseStage


class SchemaValidationStage(BaseStage):
    def _run(self, problem_dir: Path, problem_data: dict, **kwargs) -> tuple[bool, list[str]]:
        WebArenaProblemData.model_validate(problem_data)
        
        compose_path = problem_dir / "docker-compose.yaml"
        if not compose_path.exists():
            compose_path = problem_dir / "docker-compose.yml"
        
        with open(compose_path) as f:
            yaml.safe_load(f)
        
        tasks_dir = problem_dir / "tasks"
        assert tasks_dir.is_dir(), f"tasks/ is not a directory: {tasks_dir}"
        
        for task_file in problem_data["tasks"]:
            task_path = tasks_dir / task_file
            with open(task_path) as f:
                task_data = json.load(f)
            WebArenaTask.model_validate(task_data)
        
        return True, []

