import json
import subprocess
import time
from pathlib import Path
from urllib.request import urlopen
from urllib.error import URLError

from code_tools.logging_config import get_logger
from .base import BaseStage

logger = get_logger(__name__)


class ComposeHealthStage(BaseStage):
    def _run(self, problem_dir: Path, problem_data: dict, **kwargs) -> tuple[bool, list[str]]:
        compose_project = kwargs["compose_project"]
        
        compose_filename = "docker-compose.yaml"
        
        logger.info(f"🐳 Docker Compose Health Check")
        logger.info(f"  Compose project: {compose_project}")
        logger.info(f"  Problem directory: {problem_dir}")
        logger.info(f"  Compose file: {compose_filename}")
        
        logger.debug(f"\n📋 Running docker compose config...")
        result = subprocess.run(
            ["docker", "compose", "-f", compose_filename, "-p", compose_project, "config"],
            cwd=problem_dir,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode != 0:
            logger.error(f"  ❌ Config failed: {result.stderr.strip()}")
            return False, [f"Docker compose config failed: {result.stderr.strip()}"]
        
        # Parse and display environment variables from config
        logger.debug(f"  ✅ Config validated")
        config_lines = result.stdout.split('\n')
        in_environment = False
        env_vars = []
        for line in config_lines:
            if 'environment:' in line:
                in_environment = True
            elif in_environment:
                if line.strip().startswith('-') or line.strip().startswith('NODE_ENV') or line.strip().startswith('PORT') or line.strip().startswith('SKIN') or line.strip().startswith('SEED') or line.strip().startswith('DATABASE'):
                    env_vars.append(line.strip())
                elif not line.strip() or (line and not line[0].isspace()):
                    in_environment = False
        
        if env_vars:
            logger.debug(f"\n  🔧 Environment variables:")
            for var in env_vars:
                logger.debug(f"    {var}")
        
        logger.info(f"\n🚀 Starting Docker Compose services...")
        
        result = subprocess.run(
            ["docker", "compose", "-f", compose_filename, "-p", compose_project, "up", "-d"],
            cwd=problem_dir,
            capture_output=True,
            text=True,
            timeout=300
        )
        
        if result.returncode != 0:
            logger.error(f"  ❌ Docker compose up failed: {result.stderr.strip()}")
            return False, [f"Docker compose up failed: {result.stderr.strip()}"]
        
        logger.success(f"  ✅ Services started")
        
        max_wait = 60
        wait_interval = 2
        elapsed = 0
        
        logger.debug(f"\n⏳ Waiting for services to become healthy (max {max_wait}s)...")
        while elapsed < max_wait:
            result = subprocess.run(
                ["docker", "compose", "-f", compose_filename, "-p", compose_project, "ps", "--format", "json"],
                cwd=problem_dir,
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                all_running = True
                services_status = []
                for line in result.stdout.strip().split("\n"):
                    if line:
                        service = json.loads(line)
                        services_status.append(f"{service.get('Service', 'unknown')}:{service['State']}")
                        if service["State"] != "running":
                            all_running = False
                
                if elapsed % 10 == 0 or all_running:  # Log every 10s or when all running
                    logger.debug(f"  [{elapsed}s] Services: {', '.join(services_status)}")
                
                if all_running:
                    logger.debug(f"  ✅ All services running after {elapsed}s")
                    break
            
            time.sleep(wait_interval)
            elapsed += wait_interval
        else:
            logger.error(f"  ❌ Services did not become healthy within {max_wait}s")
            return False, [f"Services did not become healthy within {max_wait}s"]
        
        base_url = problem_data.get("base_url")
        if not base_url:
            logger.success(f"\n✅ No base_url to check - health check complete")
            return True, []
        
        logger.info(f"\n🌐 Checking base URL accessibility: {base_url}")
        max_wait_url = 360  
        elapsed = 0
        
        while elapsed < max_wait_url:
            try:
                response = urlopen(base_url, timeout=5)
                if response.status == 200:
                    logger.success(f"  ✅ Base URL accessible (HTTP {response.status}) after {elapsed}s")
                    return True, []
                else:
                    logger.debug(f"  [{elapsed}s] HTTP {response.status} - retrying...")
            except (URLError, OSError) as e:
                if elapsed % 30 == 0:  # Log every 30s
                    logger.debug(f"  [{elapsed}s] Not accessible yet: {type(e).__name__} (may be seeding database...)")
            
            time.sleep(wait_interval)
            elapsed += wait_interval
        
        logger.error(f"  ❌ Base URL not accessible within {max_wait_url}s")
        logger.error(f"\n📜 Docker logs (last 100 lines):")
        logger.error("=" * 80)
        try:
            logs_result = subprocess.run(
                ["docker", "compose", "-f", compose_filename, "-p", compose_project, "logs", "--tail=100"],
                cwd=problem_dir,
                capture_output=True,
                text=True,
                timeout=10
            )
            logger.error(logs_result.stdout if logs_result.returncode == 0 else f"Failed to get logs: {logs_result.stderr}")
        except Exception as e:
            logger.error(f"Error getting logs: {str(e)}")
        logger.error("=" * 80)
        return False, [f"Base URL {base_url} not accessible within {max_wait_url}s"]


