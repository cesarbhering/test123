import json
from pathlib import Path

import typer
from rich.console import Console

console = Console()


class WebArenaCreator:
    def collect_inputs(self) -> dict:
        console.print("\n[bold]Problem Information:[/bold]")
        problem_id = typer.prompt("Problem ID (e.g., frontier_bank)", type=str)
        description = typer.prompt("Description", type=str, default="")
        base_url = typer.prompt("Base URL (e.g., http://localhost:8080)", type=str, default="")
        
        return {
            "instance_id": problem_id,
            "description": description,
            "base_url": base_url
        }
    
    def create_structure(self, output_dir: Path, inputs: dict) -> Path:
        problem_id = inputs["instance_id"]
        description = inputs["description"]
        base_url = inputs["base_url"]
        
        problem_dir = output_dir / "webarena" / problem_id
        problem_dir.mkdir(parents=True, exist_ok=True)
        
        console.print(f"\n[bold green]Creating WebArena problem structure:[/bold green]")
        console.print(f"  Location: {problem_dir}")
        console.print(f"  Problem ID: {problem_id}")
        
        metadata = {
            "benchmark": "webarena",
            "problem_data": {
                "instance_id": problem_id,
                "description": description,
                "base_url": base_url,
                "require_reset": False,
                "tasks": ["task_1.json"]
            }
        }
        
        (problem_dir / "metadata.json").write_text(json.dumps(metadata, indent=2))
        console.print("  ✓ Created metadata.json")
        
        (problem_dir / "docker-compose.yaml").write_text(
            "version: '3.8'\n\n"
            "services:\n"
            "  # TODO: Add your services here\n"
            "  # Example:\n"
            "  # web:\n"
            "  #   image: nginx:alpine\n"
            "  #   ports:\n"
            "  #     - \"8080:80\"\n"
            "  #   healthcheck:\n"
            "  #     test: [\"CMD\", \"wget\", \"--quiet\", \"--tries=1\", \"--spider\", \"http://localhost:80\"]\n"
            "  #     interval: 10s\n"
            "  #     timeout: 5s\n"
            "  #     retries: 3\n"
        )
        console.print("  ✓ Created docker-compose.yaml")
        
        tasks_dir = problem_dir / "tasks"
        tasks_dir.mkdir(exist_ok=True)
        
        task_template = {
            "sites": ["example"],
            "task_id": 1,
            "require_login": False,
            "storage_state": None,
            "start_url": base_url or "http://localhost:8080",
            "geolocation": None,
            "intent": "TODO: Add task intent here",
            "require_reset": False,
            "eval": {
                "eval_types": ["string_match"],
                "reference_answers": ["TODO: Add expected answer"],
                "reference_url": "",
                "program_html": []
            },
            "reference_action_sequence": {
                "action_set_tag": "playwright",
                "action_sequence": [
                    "page.goto('http://localhost:8080')",
                    "page.stop('success')"
                ]
            }
        }
        
        (tasks_dir / "task_1.json").write_text(json.dumps(task_template, indent=2))
        console.print("  ✓ Created tasks/task_1.json")
        
        env_dir = problem_dir / "environment"
        env_dir.mkdir(exist_ok=True)
        (env_dir / "README.md").write_text("# Environment\n\nAdd your custom application code here if needed.\n")
        console.print("  ✓ Created environment/ directory")
        
        console.print(f"\n[bold green]✓ WebArena problem structure created![/bold green]")
        console.print(f"\n[bold]Next steps:[/bold]")
        console.print(f"1. Edit {problem_dir}/docker-compose.yaml to define your services")
        console.print(f"2. Edit {problem_dir}/tasks/task_1.json with task details")
        console.print(f"3. Add any custom code to {problem_dir}/environment/")
        console.print(f"\n[bold]Then validate:[/bold]")
        console.print(f"  alignerr validate --problem-dir {problem_dir}")
        
        return problem_dir

