import logging
import subprocess
from pathlib import Path

from playwright.sync_api import sync_playwright
from code_tools.logging_config import get_logger

from .evaluators import get_evaluator
from .task_schema import WebArenaTask

logger = get_logger(__name__)


class PlaywrightRunner:
    def __init__(self, compose_project: str):
        self.compose_project = compose_project
    
    def execute_task(self, task: WebArenaTask, problem_dir: Path) -> None:
        storage_state_path = None
        if task.storage_state:
            storage_state_path = problem_dir / task.storage_state
            logger.info(f"  📦 Storage state: {storage_state_path}")
        
        with sync_playwright() as p:
            logger.colored(logging.INFO, f"  🌐 Launching browser...", color="GREY")
            browser = p.chromium.launch(headless=True)
            
            context_options = {}
            if storage_state_path and storage_state_path.exists():
                context_options["storage_state"] = str(storage_state_path)
                logger.colored(logging.INFO, f"  ✅ Loaded storage state from {storage_state_path}", color="GREY")
            
            context = browser.new_context(**context_options)
            page = context.new_page()
            
            logger.info(f"  🔗 Navigating to: {task.start_url}")
            page.goto(task.start_url)
            logger.colored(logging.INFO, f"  📍 Current URL: {page.url}", color="GREY")
            
            local_vars = {"page": page}
            
            logger.info(f"  🎬 Executing {len(task.reference_action_sequence.action_sequence)} actions...")
            for idx, action in enumerate(task.reference_action_sequence.action_sequence, 1):
                action_str = action.strip().replace("await ", "")
                
                if action_str.startswith("page.stop("):
                    logger.colored(logging.INFO, f"    [{idx}] 🛑 Stop command - ending execution", color="GREY")
                    break
                
                if action_str.startswith("console.log("):
                    continue
                
                logger.colored(logging.INFO, f"    [{idx}] {action_str[:80]}{'...' if len(action_str) > 80 else ''}", color="GREY")
                
                try:
                    if action_str.startswith("assert "):
                        assertion = action_str[7:]
                        assert eval(assertion, {}, local_vars), f"Assertion failed: {assertion}"
                    else:
                        exec(action_str, {}, local_vars)
                    logger.colored(logging.INFO, f"         ✅ Success - Current URL: {page.url}", color="GREY")
                except Exception as e:
                    logger.error(f"         ❌ Error: {str(e)}")
                    logger.error(f"         📍 Current URL: {page.url}")
                    logger.error(f"\n📜 Docker container logs (last 200 lines):")
                    logger.error("=" * 80)
                    logger.error(self._get_docker_logs(problem_dir))
                    logger.error("=" * 80)
                    raise
            
            logger.info(f"  🔍 Running evaluator...")
            evaluator = get_evaluator(task)
            evaluator.evaluate(page, task)
            logger.info(f"  ✅ Evaluation passed")
            
            browser.close()
    
    def _get_docker_logs(self, problem_dir: Path) -> str:
        try:
            compose_filename = "docker-compose.yaml"
            result = subprocess.run(
                ["docker", "compose", "-f", compose_filename, "-p", self.compose_project, "logs", "--tail=200"],
                cwd=problem_dir,
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout
            else:
                return f"Failed to get logs: {result.stderr}"
        except Exception as e:
            return f"Error getting Docker logs: {str(e)}"
