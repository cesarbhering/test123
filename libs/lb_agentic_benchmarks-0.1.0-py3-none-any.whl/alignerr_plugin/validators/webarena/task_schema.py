from typing import Literal

from pydantic import BaseModel, Field


class EvalConfig(BaseModel):
    eval_types: list[str]
    reference_answers: list[str] = Field(default_factory=list)
    reference_url: str = ""
    program_html: list[dict] = Field(default_factory=list)


class ReferenceActionSequence(BaseModel):
    action_set_tag: str
    action_sequence: list[str]


class WebArenaTask(BaseModel):
    sites: list[str]
    task_id: int
    require_login: bool
    storage_state: str | None
    start_url: str
    geolocation: dict | None = None
    intent: str
    require_reset: bool
    eval: EvalConfig
    reference_action_sequence: ReferenceActionSequence


class WebArenaProblemData(BaseModel):
    instance_id: str
    description: str = ""
    base_url: str = ""
    require_reset: bool = False
    tasks: list[str]

