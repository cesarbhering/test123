from abc import ABC, abstractmethod
from pathlib import Path

from playwright.sync_api import Page

from .task_schema import WebArenaTask


class Evaluator(ABC):
    @abstractmethod
    def evaluate(self, page: Page, task: WebArenaTask) -> None:
        """Evaluate the task result. Raises AssertionError if validation fails."""
        pass


class StringMatchEvaluator(Evaluator):
    @staticmethod
    def clean_answer(answer: str) -> str:
        answer = answer.strip()
        if answer.startswith("'") and answer.endswith("'"):
            answer = answer[1:-1]
        elif answer.startswith('"') and answer.endswith('"'):
            answer = answer[1:-1]
        return answer.lower()
    
    def evaluate(self, page: Page, task: WebArenaTask) -> None:
        body_text = page.text_content("body")
        
        for answer in task.eval.reference_answers:
            clean_ref = self.clean_answer(answer)
            clean_pred = self.clean_answer(body_text)
            assert clean_ref in clean_pred, f"Expected '{answer}' not found in page body"


class URLMatchEvaluator(Evaluator):
    def evaluate(self, page: Page, task: WebArenaTask) -> None:
        current_url = page.url.rstrip("/")
        ref_urls = [url.rstrip("/") for url in task.eval.reference_url.split(" |OR| ")]
        
        matched = any(ref_url in current_url for ref_url in ref_urls)
        assert matched, f"URL mismatch: expected one of {ref_urls}, got {current_url}"


class ProgramHTMLEvaluator(Evaluator):
    def evaluate(self, page: Page, task: WebArenaTask) -> None:
        for target in task.eval.program_html:
            target_url = target.get("url", "")
            
            if target_url and target_url != "last":
                page.goto(target_url)
            
            locator = target["locator"]
            
            if not locator.strip():
                selected_element = page.content()
            elif locator.startswith("document."):
                selected_element = str(page.evaluate(f"() => {locator}"))
            else:
                raise ValueError(f"Unsupported locator type: {locator}")
            
            required_contents = target["required_contents"]
            for content in required_contents:
                assert content in selected_element, f"Required content not found: '{content}'"


class EvaluatorCombination:
    def __init__(self, evaluators: list[Evaluator]):
        self.evaluators = evaluators
    
    def evaluate(self, page: Page, task: WebArenaTask) -> None:
        for evaluator in self.evaluators:
            evaluator.evaluate(page, task)


def get_evaluator(task: WebArenaTask) -> EvaluatorCombination:
    evaluators: list[Evaluator] = []
    
    for eval_type in task.eval.eval_types:
        if eval_type == "string_match":
            evaluators.append(StringMatchEvaluator())
        elif eval_type == "url_match":
            evaluators.append(URLMatchEvaluator())
        elif eval_type == "program_html":
            evaluators.append(ProgramHTMLEvaluator())
        else:
            raise ValueError(f"Unknown eval_type: {eval_type}")
    
    return EvaluatorCombination(evaluators)
