import json
import subprocess
import time
from pathlib import Path

from alignerr.schemas import StageResult, ValidationResult
from code_tools.logging_config import get_logger

from .stages import ComposeHealthStage, GroundTruthStage, SchemaValidationStage, MetricsValidationStage
from .task_schema import WebArenaProblemData

logger = get_logger(__name__)


class WebArenaValidator:
    def load_submission(self, problem_dir: Path) -> dict:
        metadata_path = problem_dir / "metadata.json"
        return json.loads(metadata_path.read_text())
    
    def get_problem_id(self, problem_data: dict) -> str:
        return problem_data["instance_id"]
    
    def validate(
        self,
        problem_dir: Path,
        results_dir: Path,
        project_root: Path,
    ) -> ValidationResult:
        submission_data = self.load_submission(problem_dir)
        problem_data = submission_data["problem_data"]
        
        validated_problem = WebArenaProblemData.model_validate(problem_data)
        problem_id = validated_problem.instance_id
        
        results_dir.mkdir(parents=True, exist_ok=True)
        
        stages: dict[str, StageResult] = {}
        compose_project = f"webarena-{problem_id}-{int(time.time())}"
        
        try:
            logger.section("Stage 1: Schema Validation")
            stages["schema_validation"] = SchemaValidationStage().execute(problem_dir, problem_data)
            if not stages["schema_validation"].passed:
                return self._build_result(validated_problem, stages, "invalid")
            
            logger.section("Stage 2: Task Quality Metrics Validation")
            stages["metrics_validation"] = MetricsValidationStage().execute(problem_dir, problem_data)
            if not stages["metrics_validation"].passed:
                return self._build_result(validated_problem, stages, "invalid")
            
            logger.section("Stage 3: Docker Compose Health Check")
            stages["compose_health"] = ComposeHealthStage().execute(
                problem_dir, problem_data, compose_project=compose_project
            )
            if not stages["compose_health"].passed:
                return self._build_result(validated_problem, stages, "invalid")
            
            logger.section("Stage 4: Ground Truth Validation")
            stages["ground_truth"] = GroundTruthStage().execute(
                problem_dir, problem_data, compose_project=compose_project
            )
            if not stages["ground_truth"].passed:
                return self._build_result(validated_problem, stages, "invalid")
            
            return self._build_result(validated_problem, stages, "valid")
        
        except Exception as e:
            logger.error(f"Validation failed with unexpected error: {e}")
            stages["error"] = StageResult(
                passed=False,
                issues=[f"Unexpected error: {str(e)}"],
                duration_ms=0,
            )
            return self._build_result(validated_problem, stages, "error")
        
        finally:
            self._cleanup_compose(problem_dir, compose_project)
    
    def _cleanup_compose(self, problem_dir: Path, compose_project: str) -> None:
        compose_filename = "docker-compose.yaml"
        
        logger.info(f"Cleaning up Docker Compose project: {compose_project}")
        subprocess.run(
            ["docker", "compose", "-f", compose_filename, "-p", compose_project, "down", "-v", "--rmi", "local"],
            cwd=problem_dir,
            capture_output=True,
            timeout=60
        )
    
    def _build_result(
        self,
        problem: WebArenaProblemData,
        stages: dict[str, StageResult],
        status: str
    ) -> ValidationResult:
        return ValidationResult(
            problem_id=problem.instance_id,
            benchmark="webarena",
            status=status,
            stages=stages,
            metadata={
                "instance_id": problem.instance_id,
                "num_tasks": len(problem.tasks),
                "description": problem.description,
            },
        )

