import logging

from alignerr.plugins import PluginRegistry
from alignerr_plugin.validators.swe_bench.validator import SWEBenchValidator
from alignerr_plugin.validators.swe_bench.creator import SWEBenchCreator
from alignerr_plugin.validators.webarena.validator import WebArenaValidator
from alignerr_plugin.validators.webarena.creator import WebArenaCreator
from alignerr_plugin.commands import evaluate, report
from alignerr_plugin.result_handler import BenchmarkResultHandler

# Silence code_tools console logging - only show warnings and above
for handler in logging.root.handlers:
    if isinstance(handler, logging.StreamHandler):
        handler.setLevel(logging.WARNING)

def setup_plugins(registry: PluginRegistry):
    registry.register_benchmark(
        "swe_bench",
        SWEBenchValidator(),
        SWEBenchCreator()
    )
    registry.register_benchmark(
        "webarena",
        WebArenaValidator(),
        WebArenaCreator()
    )
    registry.register_command("evaluate", evaluate)
    registry.register_command("report", report)
    registry.register_result_handler(BenchmarkResultHandler())
