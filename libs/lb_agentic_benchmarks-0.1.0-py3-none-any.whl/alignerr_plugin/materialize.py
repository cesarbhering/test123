import hashlib
import subprocess
from pathlib import Path


def compute_content_hash(repo_url: str, commit: str, subdir: str | None = None) -> str:
    content = f"{repo_url}@{commit}"
    if subdir:
        content += f":{subdir}"
    return hashlib.sha256(content.encode()).hexdigest()[:16]


def materialize_repo(
    repo_url: str,
    commit: str,
    cache_root: Path,
    subdir: str | None = None,
) -> Path:
    content_hash = compute_content_hash(repo_url, commit, subdir)
    workspace_path = cache_root / "repos" / content_hash
    
    if workspace_path.exists():
        return workspace_path / subdir if subdir else workspace_path
    
    workspace_path.mkdir(parents=True, exist_ok=True)
    
    subprocess.run(
        ["git", "clone", "--depth", "1", "--no-tags", repo_url, str(workspace_path)],
        check=True,
        capture_output=True,
    )
    
    subprocess.run(
        ["git", "fetch", "--depth", "1", "origin", commit],
        cwd=workspace_path,
        check=True,
        capture_output=True,
    )
    
    subprocess.run(
        ["git", "checkout", commit],
        cwd=workspace_path,
        check=True,
        capture_output=True,
    )
    
    actual_commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=workspace_path,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    
    assert actual_commit == commit, f"Commit mismatch: {actual_commit} != {commit}"
    
    return workspace_path / subdir if subdir else workspace_path

