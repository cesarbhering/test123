import json
from pathlib import Path
from urllib.parse import quote
import typer
from rich.console import Console
from dotenv import load_dotenv
from pydantic import TypeAdapter

from alignerr_plugin.schemas import ProblemSubmission
from alignerr_plugin.evaluators.runner import run_evaluation
from alignerr_plugin.reporting.generator import generate_html_report
from alignerr_plugin.reporting.validation_generator import generate_validation_report
from alignerr_plugin.reporting.submission_generator import generate_submission_report
from alignerr_plugin.reporting.data_loader import load_validation_data, load_agent_aggregate_results

console = Console()


def find_validation_dir(problem_id: str, result_dir: Path, project_root: Path) -> Path | None:
    """Search for validation data in multiple locations."""
    search_paths = [
        project_root / ".alignerr" / "validations" / problem_id,
        result_dir.parent / ".alignerr" / "validations" / problem_id,
        result_dir.parent.parent / ".alignerr" / "validations" / problem_id,
        result_dir / ".." / ".alignerr" / "validations" / problem_id,
    ]
    for path in search_paths:
        resolved = path.resolve()
        if resolved.exists() and (resolved / "validation_result.json").exists():
            return resolved
    return None

def evaluate(
    config_path: Path = typer.Option(
        ...,
        "--config-path",
        "-c",
        help="Path to YAML configuration file",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
    ),
    problem_dir: Path = typer.Option(
        ...,
        "--problem-dir",
        "-d",
        help="Path to unpacked problem directory containing metadata.json",
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
    ),
    project_root: Path = typer.Option(
        Path.cwd(),
        "--project-root",
        "-p",
        help="Project root directory",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    env_file: Path = typer.Option(
        Path(".env"),
        "--env-file",
        help=".env file to load environment variables from",
    ),
    rebuild_image: bool = typer.Option(
        False,
        "--rebuild-image",
        help="Rebuild Docker image before running",
    ),
    task_index: int | None = typer.Option(
        None,
        "--task-index",
        help="Run specific task by index (0-based)",
    ),
    task_name: str | None = typer.Option(
        None,
        "--task-name",
        help="Run specific task by name pattern (partial match)",
    ),
    run_all: bool = typer.Option(
        False,
        "--run-all",
        help="Run all tasks instead of just the first one",
    ),
) -> None:
    """Run evaluation on an unpacked problem."""
    if env_file.exists():
        console.print(f"Loading environment from: {env_file}")
        load_dotenv(env_file)
    
    console.print("[bold green]Starting evaluation[/bold green]")
    console.print(f"Config: {config_path}")
    console.print(f"Problem directory: {problem_dir}")
    console.print(f"Project root: {project_root}")
    
    metadata_path = problem_dir / "metadata.json"
    if not metadata_path.exists():
        console.print("[red]Error: metadata.json not found in problem directory[/red]")
        raise typer.Exit(code=1)
    
    submission_data = json.loads(metadata_path.read_text())
    
    problem_data = submission_data.get("problem_data", {})
    
    problem_txt = problem_dir / "problem.txt"
    if problem_txt.exists():
        problem_data["problem_statement"] = problem_txt.read_text().strip()
    
    setup_sh = problem_dir / "setup.sh"
    if setup_sh.exists():
        problem_data["environment_setup_script"] = setup_sh.read_text()
    
    test_sh = problem_dir / "test.sh"
    if test_sh.exists():
        problem_data["test_script"] = test_sh.read_text()
    
    solution_patch = problem_dir / "solution.patch"
    if solution_patch.exists():
        problem_data["patch"] = solution_patch.read_text()
    
    test_patch = problem_dir / "test.patch"
    if test_patch.exists():
        problem_data["test_patch"] = test_patch.read_text()
    
    submission_data["problem_data"] = problem_data
    
    adapter = TypeAdapter(ProblemSubmission)
    submission = adapter.validate_python(submission_data)
    
    run_evaluation(
        config_path, 
        submission, 
        project_root, 
        rebuild_image, 
        problem_dir,
        task_index=task_index,
        task_name=task_name,
        run_all=run_all,
    )
    console.print("[bold green]Evaluation completed successfully[/bold green]")

def report(
    result_dir: Path = typer.Option(
        ...,
        "--result-dir",
        "-r",
        help="Path to result directory (results/{run_id})",
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
    ),
    project_root: Path = typer.Option(
        Path.cwd(),
        "--project-root",
        "-p",
        help="Project root directory",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
) -> None:
    console.print("[bold green]Generating HTML reports[/bold green]")
    console.print(f"Result directory: {result_dir}")
    console.print(f"Project root: {project_root}")
    
    agent_dirs = [item for item in result_dir.iterdir() if item.is_dir()]
    
    if not agent_dirs:
        console.print("[yellow]No agent directories found[/yellow]")
        raise typer.Exit(code=1)
    
    problem_agents = {}
    for agent_dir in agent_dirs:
        agent_name = agent_dir.name
        for problem_dir in agent_dir.iterdir():
            if problem_dir.is_dir():
                problem_id = problem_dir.name
                if problem_id not in problem_agents:
                    problem_agents[problem_id] = {}
                problem_agents[problem_id][agent_name] = problem_dir
    
    console.print(f"Found {len(problem_agents)} problem(s) across {len(agent_dirs)} agent(s)")
    
    for problem_id, agents_data in problem_agents.items():
        console.print(f"\nProcessing problem: {problem_id}")
        console.print(f"  Agents: {', '.join(agents_data.keys())}")
        
        for agent_name, problem_dir in agents_data.items():
            console.print(f"\n  Agent: {agent_name}")
            
            task_dirs = [
                item for item in problem_dir.iterdir()
                if item.is_dir() and (item / "result.json").exists()
            ]
            
            for task_dir in task_dirs:
                task_id = task_dir.name
                trajectory_json = task_dir / "trajectory.json"
                
                if not trajectory_json.exists():
                    console.print(f"    [yellow]Skipping {task_id}: trajectory.json not found[/yellow]")
                    continue
                
                output_path = task_dir / "report.html"
                
                try:
                    generate_html_report(task_dir, project_root, output_path)
                    file_url = "file://" + quote(str(output_path.resolve()), safe="/:")
                    console.print(f"    [green]✓[/green] [link={file_url}]{task_id}/report.html[/link]")
                except Exception as e:
                    console.print(f"    [red]✗ Task report failed for {task_id}: {e}[/red]")
        
        validation_dir = find_validation_dir(problem_id, result_dir, project_root)
        validation_data = None
        validation_report_relative_path = None
        if validation_dir:
            console.print(f"  Found validation data at: {validation_dir}")
            try:
                validation_data = load_validation_data(validation_dir)
                validation_report_path = result_dir / f"{problem_id}_validation.html"
                generate_validation_report(validation_dir, validation_report_path)
                validation_report_relative_path = f"{problem_id}_validation.html"
                file_url = "file://" + quote(str(validation_report_path.resolve()), safe="/:")
                console.print(f"  [green]✓[/green] [link={file_url}]{problem_id}_validation.html[/link]")
            except Exception as e:
                console.print(f"  [yellow]⚠ Validation report failed: {e}[/yellow]")
        else:
            console.print(f"  [yellow]No validation data found for {problem_id}[/yellow]")
        
        agent_results = load_agent_aggregate_results(agents_data)
        _print_results_summary(console, problem_id, agent_results, agents_data)
        
        console.print(f"\n  Generating aggregated report for {problem_id}")
        try:
            aggregated_report_path = result_dir / "index.html"
            generate_submission_report(
                result_dir,
                project_root,
                aggregated_report_path,
                validation_data,
                problem_id=problem_id,
                agents_data=agents_data,
                validation_report_path=validation_report_relative_path,
            )
            file_url = "file://" + quote(str(aggregated_report_path.resolve()), safe="/:")
            console.print(f"  [green]✓[/green] [link={file_url}]index.html[/link]")
        except Exception as e:
            console.print(f"  [red]✗ Aggregated report failed: {e}[/red]")
    
    console.print(f"\n[bold green]All reports generated[/bold green]")


def _print_results_summary(console: Console, problem_id: str, agent_results: dict, agents_data: dict) -> None:
    """Print actionable summary of evaluation results."""
    console.print(f"\n  [bold]Results Summary for {problem_id}[/bold]")
    console.print("  " + "=" * 60)
    
    for agent_name, aggregate in agent_results.items():
        if not aggregate:
            continue
        metrics = aggregate.get("metrics", {})
        resolved = metrics.get("resolved", 0)
        successful = metrics.get("successful_tasks", 0)
        failed = metrics.get("failed_tasks", 0)
        total = metrics.get("total_tasks", 0)
        runtime = metrics.get("runtime_seconds", 0)
        
        status_color = "green" if resolved >= 0.5 else "yellow" if resolved > 0 else "red"
        console.print(f"\n  [{status_color}]{agent_name}[/{status_color}]")
        console.print(f"    Pass rate: {resolved * 100:.1f}% ({successful}/{total} tasks)")
        console.print(f"    Runtime: {runtime:.1f}s")
    
    console.print(f"\n  [bold]Failed Tasks[/bold]")
    
    failure_count = 0
    for agent_name, problem_dir in agents_data.items():
        for task_dir in problem_dir.iterdir():
            if not task_dir.is_dir():
                continue
            result_file = task_dir / "result.json"
            if not result_file.exists():
                continue
            result = json.loads(result_file.read_text())
            if result.get("status") not in ["failed", "error"]:
                continue
            
            failure_count += 1
            task_name = task_dir.name
            details = result.get("details", {})
            intent = details.get("intent", "N/A")
            evaluation = details.get("evaluation", "N/A")
            quality = result.get("quality_metrics", {})
            failure_mode = quality.get("failure_mode", "unknown")
            
            console.print(f"\n  [red]✗ {agent_name}/{task_name}[/red]")
            console.print(f"    Intent: {intent}")
            console.print(f"    Reason: {evaluation}")
            console.print(f"    Failure mode: {failure_mode}")
    
    if failure_count == 0:
        console.print("  [green]No failures[/green]")

