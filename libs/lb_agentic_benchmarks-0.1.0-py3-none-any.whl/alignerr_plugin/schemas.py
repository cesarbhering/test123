from typing import Annotated, Literal
from pydantic import Field
from alignerr.schemas import BaseProblemSubmission, ValidationResult, StageResult

class SWEBenchSubmission(BaseProblemSubmission):
    benchmark: Literal["swe_bench"] = "swe_bench"
    repo_url: str = Field(min_length=1)
    commit: str = Field(pattern=r"^[a-f0-9]{40}$")
    docker_image: str = Field(min_length=1, description="Docker image to use for validation")

class WebArenaSubmission(BaseProblemSubmission):
    benchmark: Literal["webarena"] = "webarena"

ProblemSubmission = Annotated[
    SWEBenchSubmission | WebArenaSubmission,
    Field(discriminator="benchmark")
]
