from pydantic import BaseModel


class Resources(BaseModel):
    cpus: float
    memory_mb: int


class BenchmarkConfig(BaseModel):
    name: str
    compose_path: str


class ModelConfig(BaseModel):
    name: str
    temperature: float | None = None
    top_p: float | None = None
    per_instance_cost_limit: float = 50.0
    total_cost_limit: float = 0.0


class AgentTemplatesConfig(BaseModel):
    system_template: str
    instance_template: str
    next_step_template: str = "OBSERVATION:\n{{observation}}"
    next_step_no_output_template: str = "Your command ran successfully and did not produce any output."


class BundleConfig(BaseModel):
    path: str


class ParseFunctionConfig(BaseModel):
    type: str


class ToolsConfig(BaseModel):
    env_variables: dict[str, str] | None = None
    bundles: list[BundleConfig] | None = None
    registry_variables: dict[str, str | list[str]] | None = None
    enable_bash_tool: bool = True
    parse_function: ParseFunctionConfig | None = None


class HistoryProcessorConfig(BaseModel):
    type: str
    last_n_messages: int | None = None


class AgentConfig(BaseModel):
    name: str
    model: ModelConfig
    templates: AgentTemplatesConfig | None = None
    tools: ToolsConfig | None = None
    history_processors: list[HistoryProcessorConfig] | None = None


class DockerConfig(BaseModel):
    default_resources: dict[str, int | float]


class RunConfig(BaseModel):
    run_id: str
    timeout_seconds: int
    docker: DockerConfig
    agents: list[AgentConfig]
    benchmark: BenchmarkConfig


class TaskSpec(BaseModel):
    task_id: str
    benchmark: str
    repo_url: str | None = None
    commit: str | None = None
    timeout_seconds: int
    resources: Resources
    docker_image: str | None = None
    problem_data: dict
    agent: AgentConfig


class TimingMs(BaseModel):
    total: int
    setup: int
    eval: int


class Result(BaseModel):
    task_id: str
    benchmark: str
    status: str
    metrics: dict
    details: dict
    artifacts: list[str]
    timing_ms: TimingMs
    version: int = 1

