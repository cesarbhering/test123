import json
import subprocess
import time
from abc import ABC, abstractmethod
from pathlib import Path

from alignerr_plugin.schemas import ProblemSubmission
import yaml

from alignerr_plugin.materialize import materialize_repo
from alignerr_plugin.evaluators.dto import (
    Resources,
    BenchmarkConfig,
    DockerConfig,
    RunConfig,
    TaskSpec,
    TimingMs,
    Result,
)
import sys
from code_tools.logging_config import get_logger

logger = get_logger(__name__)


class WorkspaceStrategy(ABC):
    @abstractmethod
    def get_workspace(
        self,
        submission: ProblemSubmission,
        task_spec: TaskSpec,
        cache_root: Path,
        project_root: Path,
        problem_dir: Path | None = None,
    ) -> Path:
        pass


class SWEBenchWorkspaceStrategy(WorkspaceStrategy):
    def get_workspace(
        self,
        submission: ProblemSubmission,
        task_spec: TaskSpec,
        cache_root: Path,
        project_root: Path,
        problem_dir: Path | None = None,
    ) -> Path:
        return materialize_repo(
            task_spec.repo_url,
            task_spec.commit,
            cache_root,
        )


class WebArenaWorkspaceStrategy(WorkspaceStrategy):
    def get_workspace(
        self,
        submission: ProblemSubmission,
        task_spec: TaskSpec,
        cache_root: Path,
        project_root: Path,
        problem_dir: Path | None = None,
    ) -> Path:
        if problem_dir is None:
            raise ValueError("WebArena requires problem_dir to be provided")

        if not problem_dir.exists():
            raise FileNotFoundError(f"WebArena problem directory not found: {problem_dir}")

        return problem_dir


class WorkspaceStrategyFactory:
    _strategies = {
        "swe_bench": SWEBenchWorkspaceStrategy(),
        "webarena": WebArenaWorkspaceStrategy(),
    }

    @classmethod
    def get_strategy(cls, benchmark: str) -> WorkspaceStrategy:
        strategy = cls._strategies.get(benchmark)
        if not strategy:
            return SWEBenchWorkspaceStrategy()
        return strategy


def load_config(config_path: Path) -> RunConfig:
    with config_path.open() as f:
        config_dict = yaml.safe_load(f)
    return RunConfig.model_validate(config_dict)


class ExecutionStrategy(ABC):
    @abstractmethod
    def execute(
        self,
        task_spec: TaskSpec,
        workspace_path: Path,
        task_dir: Path,
        results_dir: Path,
        project_root: Path,
        rebuild_image: bool = False,
        task_index: int | None = None,
        task_name: str | None = None,
        run_all: bool = False,
    ) -> Result:
        pass


class DockerExecutionStrategy(ExecutionStrategy):
    def __init__(self, compose_path: Path):
        self.compose_path = compose_path

    def execute(
        self,
        task_spec: TaskSpec,
        workspace_path: Path,
        task_dir: Path,
        results_dir: Path,
        project_root: Path,
        rebuild_image: bool = False,
        task_index: int | None = None,
        task_name: str | None = None,
        run_all: bool = False,
    ) -> Result:
        # Note: Docker execution doesn't support task selection yet
        # These parameters are ignored for Docker execution
        return run_evaluator_compose(
            task_spec,
            workspace_path,
            self.compose_path,
            task_dir,
            results_dir,
            rebuild_image,
        )


class DirectExecutionStrategy(ExecutionStrategy):
    def __init__(self, evaluator_script: str):
        self.evaluator_script = evaluator_script

    def execute(
        self,
        task_spec: TaskSpec,
        workspace_path: Path,
        task_dir: Path,
        results_dir: Path,
        project_root: Path,
        rebuild_image: bool = False,
        task_index: int | None = None,
        task_name: str | None = None,
        run_all: bool = False,
    ) -> Result:
        return run_evaluator_direct(
            task_spec,
            workspace_path,
            self.evaluator_script,
            task_dir,
            results_dir,
            project_root,
            task_index=task_index,
            task_name=task_name,
            run_all=run_all,
        )


def run_evaluator_compose(
    task_spec: TaskSpec,
    workspace_path: Path,
    compose_path: Path,
    task_dir: Path,
    results_dir: Path,
    rebuild_image: bool = False,
) -> Result:
    start_time = time.time()

    task_dir.mkdir(parents=True, exist_ok=True)
    results_dir.mkdir(parents=True, exist_ok=True)

    task_json_path = task_dir / "task.json"
    task_json_path.write_text(task_spec.model_dump_json(indent=2))

    compose_dir = compose_path.parent

    abs_task_dir = task_dir.resolve()
    abs_workspace_path = workspace_path.resolve()
    abs_results_dir = results_dir.resolve()

    try:
        cmd = ["docker", "compose"]

        if rebuild_image:
            subprocess.run(
                cmd + ["build"],
                cwd=compose_dir,
                check=True,
            )

        subprocess.run(
            cmd
            + [
                "run",
                "--rm",
                "-v",
                f"{abs_task_dir}:/task:ro",
                "-v",
                f"{abs_workspace_path}:/workspace",
                "-v",
                f"{abs_results_dir}:/results",
                "evaluator",
            ],
            cwd=compose_dir,
            check=True,
        )

        result_file = results_dir / "result.json"
        if result_file.exists():
            result_data = json.loads(result_file.read_text())
            return Result.model_validate(result_data)
        else:
            return Result(
                task_id=task_spec.task_id,
                benchmark=task_spec.benchmark,
                status="failed",
                metrics={},
                details={"notes": "No result.json produced"},
                artifacts=[],
                timing_ms=TimingMs(
                    total=int((time.time() - start_time) * 1000),
                    setup=0,
                    eval=0,
                ),
            )

    except subprocess.CalledProcessError as e:
        return Result(
            task_id=task_spec.task_id,
            benchmark=task_spec.benchmark,
            status="failed",
            metrics={},
            details={"notes": f"Docker compose failed: {str(e)}"},
            artifacts=[],
            timing_ms=TimingMs(
                total=int((time.time() - start_time) * 1000),
                setup=0,
                eval=0,
            ),
        )


def run_evaluator_direct(
    task_spec: TaskSpec,
    workspace_path: Path,
    evaluator_script: str,
    task_dir: Path,
    results_dir: Path,
    project_root: Path,
    task_index: int | None = None,
    task_name: str | None = None,
    run_all: bool = False,
) -> Result:
    """Run evaluator directly on host (no Docker)"""
    start_time = time.time()

    task_dir.mkdir(parents=True, exist_ok=True)
    results_dir.mkdir(parents=True, exist_ok=True)

    task_json_path = task_dir / "task.json"
    task_json_path.write_text(task_spec.model_dump_json(indent=2))

    evaluator_path = project_root / evaluator_script

    try:
        # Set up environment for evaluator
        evaluator_dir = evaluator_path.parent
        env = subprocess.os.environ.copy()
        env.update(
            {
                "TASK_JSON_PATH": str(task_json_path),
                "WORKSPACE_PATH": str(workspace_path),
                "RESULTS_DIR": str(results_dir),
                "PYTHONPATH": str(evaluator_dir) + ":" + env.get("PYTHONPATH", ""),
                "PYTHONUNBUFFERED": "1",  # Ensure real-time output
            }
        )

        # Ensure critical API keys are passed through
        for key in ["LABELBOX_API_KEY", "LABELBOX_BASE_URL"]:
            if key in subprocess.os.environ:
                env[key] = subprocess.os.environ[key]

        # Build command with CLI arguments instead of env vars
        cmd = [sys.executable, str(evaluator_path)]
        cmd.extend(["--task-json-path", str(task_json_path)])
        cmd.extend(["--workspace-path", str(workspace_path)])
        cmd.extend(["--results-dir", str(results_dir)])

        if task_index is not None:
            cmd.extend(["--task-index", str(task_index)])
        if task_name is not None:
            cmd.extend(["--task-name", task_name])
        if run_all:
            cmd.append("--run-all")

        # Run the evaluator script directly with Python (streaming output)
        logger.info(f"Starting evaluator for task: {task_spec.task_id}")
        logger.info(f"Evaluator script: {evaluator_path}")
        logger.info("-" * 80)

        result = subprocess.run(
            cmd,
            env=env,
            timeout=None,  # No global timeout - let individual tasks handle their own timeouts
            capture_output=False,
        )

        logger.info("-" * 80)

        if result.returncode != 0:
            logger.warning(f"⚠️  Evaluator script exited with return code {result.returncode} (this is not necessarily an error)")
            # Don't raise - let the result.json determine success/failure
            # The evaluator may have completed tasks successfully even with a non-zero exit code

        result_file = results_dir / "result.json"
        if result_file.exists():
            result_data = json.loads(result_file.read_text())
            return Result.model_validate(result_data)
        else:
            return Result(
                task_id=task_spec.task_id,
                benchmark=task_spec.benchmark,
                status="failed",
                metrics={},
                details={"notes": "No result.json produced"},
                artifacts=[],
                timing_ms=TimingMs(
                    total=int((time.time() - start_time) * 1000),
                    setup=0,
                    eval=0,
                ),
            )
    except subprocess.CalledProcessError as e:
        logger.error(f"Evaluator script failed with return code: {e.returncode}")

        return Result(
            task_id=task_spec.task_id,
            benchmark=task_spec.benchmark,
            status="failed",
            metrics={},
            details={
                "notes": f"Evaluator script failed with return code {e.returncode}",
                "return_code": e.returncode,
            },
            artifacts=[],
            timing_ms=TimingMs(
                total=int((time.time() - start_time) * 1000),
                setup=0,
                eval=0,
            ),
        )


def run_evaluation(
    config_path: Path,
    submission: ProblemSubmission,
    project_root: Path,
    rebuild_image: bool = False,
    problem_dir: Path | None = None,
    task_index: int | None = None,
    task_name: str | None = None,
    run_all: bool = False,
) -> None:
    config = load_config(config_path)

    cache_root = project_root / ".cache"
    tasks_root = project_root / "tasks"
    results_root = project_root / "results" / config.run_id

    results_root.mkdir(parents=True, exist_ok=True)

    problem_id = submission.problem_data.get("instance_id", "unknown")

    resources = Resources(
        cpus=config.docker.default_resources["cpus"],
        memory_mb=config.docker.default_resources["memory_mb"],
    )

    repo_url = getattr(submission, "repo_url", None)
    commit = getattr(submission, "commit", None)
    docker_image = getattr(submission, "docker_image", None)

    workspace_strategy = WorkspaceStrategyFactory.get_strategy(submission.benchmark)

    for agent_config in config.agents:
        agent_name = agent_config.name
        logger.info(f"Running evaluation with agent: {agent_name}")

        task_id = f"{config.run_id}-{agent_name}-{config.benchmark.name}-{problem_id}"

        task_spec = TaskSpec(
            task_id=task_id,
            benchmark=submission.benchmark,
            repo_url=repo_url,
            commit=commit,
            timeout_seconds=config.timeout_seconds,
            resources=resources,
            docker_image=docker_image,
            problem_data=submission.problem_data,
            agent=agent_config,
        )

        logger.info(f"Processing task: {task_spec.task_id}")

        try:
            workspace_path = workspace_strategy.get_workspace(
                submission,
                task_spec,
                cache_root,
                project_root,
                problem_dir,
            )
        except Exception as e:
            result = Result(
                task_id=task_spec.task_id,
                benchmark=task_spec.benchmark,
                status="failed",
                metrics={},
                details={"notes": f"Failed to get workspace: {str(e)}"},
                artifacts=[],
                timing_ms=TimingMs(total=0, setup=0, eval=0),
            )
            result_file = results_root / agent_name / problem_id / "result.json"
            result_file.parent.mkdir(parents=True, exist_ok=True)
            result_file.write_text(result.model_dump_json(indent=2))
            logger.error(f"Failed task: {task_spec.task_id} - Error: {str(e)}")
            continue

        task_dir = tasks_root / config.run_id / task_spec.task_id
        results_dir = results_root / agent_name / problem_id

        if submission.benchmark == "webarena":
            exec_strategy = DirectExecutionStrategy("evaluators/webarena/evaluate.py")
        else:
            compose_full_path = project_root / config.benchmark.compose_path
            exec_strategy = DockerExecutionStrategy(compose_full_path)

        result = exec_strategy.execute(
            task_spec,
            workspace_path,
            task_dir,
            results_dir,
            project_root,
            rebuild_image,
            task_index=task_index,
            task_name=task_name,
            run_all=run_all,
        )

        logger.info(f"Completed agent '{agent_name}' on problem '{problem_id}' - Overall status: {result.status}")

    logger.info(f"All agents completed. Results: {results_root}")
